create PACKAGE BODY STOCK_DEMANDE_STOCK_PKG AS


function creer_entete_demande(p_date_demande date, p_id_frs number, p_designation varchar2, p_num_BC varchar2, p_livreur varchar2) return varchar2
is
 p_record stock_demande_stock_v%rowtype;
 p_id_demande varchar2(50);
begin
        
        p_record.id_fournisseur := to_number(p_id_frs);
        p_record.date_demande := p_date_demande;
        p_record.NUM_BON_LIVRAISON_FRS := p_designation;        
        p_record.NUM_BON_LIVRAISON :=  get_num_BL('BDL',3,p_date_demande);  
        p_record.NUM_BON_COMMANDE := p_num_BC;
        p_record.NOM_PRENOM_LIVREUR := p_livreur;
     --   p_record.INSERT_DATE := to_date('19/03/2020','dd/mm/yyyy');
     --    p_record.INSERT_USER := v('USER');
        p_record.statut := 'STOCK_L_DRAFT';
      
     select STOCK_DEMANDE_STOCK_SEQ.nextval into    p_record.ID_DM_STOCK  from dual;
     p_id_demande := p_record.NUM_BON_LIVRAISON ;
     begin
        insert into STOCK_DEMANDE_STOCK_V values p_record;
     exception when others then
            return null;
     end;
     return p_id_demande;
end ;


function get_num_BL(p_prefixe varchar2,p_taille number,p_date date)  return varchar2
is
l_numbre number;
l_nbre_part varchar2(10);
l_num varchar2(20);
begin

select count(ID_DM_STOCK) into l_numbre
from STOCK_DEMANDE_STOCK_V
where to_char(DATE_DEMANDE,'dd/mm/yyyy') = to_char(p_date,'dd/mm/yyyy');

l_nbre_part := LPAD( to_char(l_numbre+1),  p_taille , '0' );

return p_prefixe || '_' || l_nbre_part || '_' || to_char(p_date, 'ddmmyy');

end;


  procedure creer_detail_demande (p_id_produit number, p_quantite number, p_num_BL varchar2)
  is
 p_record STOCK_DEMANDE_STOCK_DETAIL_V%rowtype;
  
  begin 
  
    for enr in (select * from stock_demande_stock_v where NUM_BON_LIVRAISON = p_num_BL) loop
    
     delete from stock_demande_stock_detail_v where ID_DM_STOCK = enr.ID_DM_STOCK and id_produit = p_id_produit;
    commit;
    
        p_record.id_produit := p_id_produit;
        p_record.QTE_LIVRE := to_number(p_quantite);
        p_record.ID_DM_STOCK :=to_number(enr.ID_DM_STOCK);
        p_record.STATUT := 'Y';
          select STOCK_DEMANDE_STOCK_DETAIL_SEQ.nextval into p_record.ID_DM_STOCK_DETAIL from dual;
    
    begin
        insert into STOCK_DEMANDE_STOCK_DETAIL_V values p_record;
     exception when others then
         null;
     end;
    end loop;
  
  end;
  
   
  procedure generer_lot(p_id_produit number, p_num_bl varchar2, p_nbre_lot number, p_qte number default null)
  is
  l_qte number;
  l_qte_lot number;
  l_qte_lot_rest number;
  l_rest number;
  l_rec stock_lots_v%rowtype;
  begin
  if p_nbre_lot > 0 then
   delete from stock_lots_v where num_bl = p_num_bl and id_produit = p_id_produit;
   for enr in (select det.*, ent.date_livraison from stock_demande_stock_detail_v det, stock_demande_stock_v ent
                        where ent.id_dm_stock= det.id_dm_stock  and ent.num_bon_livraison=p_num_bl and det.id_produit = p_id_produit) loop
                        if p_qte is null then l_qte := enr.qte_livre; end if;
                        l_qte_lot := FLOOR(l_qte / p_nbre_lot );
                        l_qte_lot_rest := mod(l_qte , p_nbre_lot );
                        l_rest := round(l_qte_lot_rest/ p_nbre_lot);
                        for i in 1..p_nbre_lot loop
                            l_rec := null;
                            l_rec.designation := 'lot N°' || to_char(i) ||  'du BL n° ' || p_num_bl;
                            l_rec.date_lot := enr.date_livraison;
                            l_rec.id_produit := p_id_produit;
                            l_rec.num_bl := p_num_bl;
                            l_rec.statut :='E';
                            if l_qte_lot_rest >=1 then
                             l_rec.quantite := l_qte_lot +l_rest;
                             else
                                    l_rec.quantite := l_qte_lot;
                             end if;
                            insert into stock_lots_v values l_rec;
                            l_qte_lot_rest := l_qte_lot_rest -1;
                        end loop;
                        
    end loop;
  end if;
  end;


function controle_preparation(p_id_demande number) return varchar2
is
l_message varchar2(320);
l_nbre number;


begin


 select count(ID_DM_STOCK) into l_nbre from STOCK_DEMANDE_STOCK_DETAIL_V where ID_DM_STOCK = p_id_demande;
 if l_nbre =0 then 
    raise_application_error(-20207, 'Vous n''avez pas ajouté de produits pour la livraison !');
 end if;
 
 for enr in (select * from STOCK_DEMANDE_STOCK_DETAIL_V where ID_DM_STOCK =p_id_demande and PRIX_ACHAT is null ) loop
    raise_application_error(-20206, 'Vous n''avez pas saisi tous les prix d''achat !');
 end loop;
 
 return null;
end ;

function controle_entreposage(p_id_demande number) return varchar2
is
l_message varchar2(320);
l_nbre number;
l_num_bl varchar2(32);


begin

select NUM_BON_LIVRAISON into l_num_bl from STOCK_DEMANDE_STOCK_V where ID_DM_STOCK = p_id_demande;
    
    for enr in (select * from STOCK_DEMANDE_STOCK_DETAIL_V where  ID_DM_STOCK =p_id_demande ) loop
    
            select count(ID_LOT) into l_nbre from STOCK_LOTS_V where NUM_BL = l_num_bl and id_produit = enr.id_produit;
             if l_nbre =0 then 
                raise_application_error(-20207, 'Vous n''avez pas effectué l''entreposage de tous les produits livrés !');
             end if;
             
               select count(ID_LOT) into l_nbre from STOCK_LOTS_V where NUM_BL = l_num_bl and id_produit = enr.id_produit and DATE_PEREMPTION is null;
             if l_nbre >0 then 
                raise_application_error(-20206, 'Vous n''avez pas saisi la date de peremption de tous les  lots. Retournez à l''étape d''entreposage pour  completer la saisie  !');
             end if;
             
              select count(ID_LOT) into l_nbre from STOCK_LOTS_V where NUM_BL = l_num_bl and id_produit = enr.id_produit and ID_LIEU is null;
             if l_nbre >0 then 
                raise_application_error(-20205, 'Vous n''avez pas saisi les lieux de stockage de tous les  lots. Retournez à l''étape d''entreposage pour  completer la saisie  !');
             end if;
             
             
    end loop;
/*

 
 
 select count(ID_LOT) into l_nbre from STOCK_LOTS_V where NUM_BL = l_num_bl;
 if l_nbre =0 then 
    raise_application_error(-20207, 'Vous n''avez pas ajouté de produits pour la livraison !');
 end if;
 
 for enr in (select * from STOCK_DEMANDE_STOCK_DETAIL_V where ID_DM_STOCK =p_id_demande and PRIX_ACHAT is null ) loop
    raise_application_error(-20206, 'Vous n''avez pas saisi tous les prix d''achat !');
 end loop;
 */
 return null;
 
end ;


procedure mvt_Entree_stock (p_num_dem number) 
is
l_mvt_stock STOCK_MVT_PRODUIT_v%rowtype;
begin

for dem in (select * from stock_demande_STOCK_v where ID_DM_STOCK = p_num_dem) loop
  for bl in (select * from stock_lots_v where NUM_BL = dem.NUM_BON_LIVRAISON) loop
        l_mvt_stock := null;
        l_mvt_stock.DATE_MVT:= dem.DATE_DEMANDE;
        l_mvt_stock.ID_PRODUIT := bl.ID_PRODUIT;
        l_mvt_stock.ID_lieu:= bl.ID_LIEU;
        l_mvt_stock.ID_TYPE_MVT := 'E';
        l_mvt_stock.ID_DEMANDE := dem.ID_DM_STOCK;
        l_mvt_stock.ID_LOT := bl.ID_LOT;
        l_mvt_stock.qte := bl.QUANTITE;
        l_mvt_stock.designation := bl.DESIGNATION;
        l_mvt_stock.id_fournisseur := dem.ID_FOURNISSEUR;
        
        insert into STOCK_MVT_PRODUIT_v values l_mvt_stock;
        
    update stock_lots_v set statut = null where id_lot = bl.ID_LOT;
        
  end loop;
end loop;
end;


END STOCK_DEMANDE_STOCK_PKG;
/

