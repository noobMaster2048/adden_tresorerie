create PACKAGE       STOCK_DEMANDE_SORTIE_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 


 function creer_entete_demande(p_date_demande date, p_id_dem varchar2, p_designation varchar2, p_id_salle varchar2) return varchar2;
 
  procedure creer_detail_demande (p_id_produit number
  , p_quantite number
  ,p_stock number
  , p_num_destock varchar2);
  
  procedure modifier_detail_demande (p_id_produit number
  , p_quantite number
  ,p_stock number
  , p_num_destock varchar2);
  
  function get_num_ordre(p_prefixe varchar2,p_taille number,p_date date) return varchar2;
  
  function controle_destockage(p_num_ordre varchar2) return varchar2;
  
    function controle_destockage(p_id_demande number) return varchar2;
  
  function destockage_Produit (p_id_produit number, p_num_ordre varchar2) return varchar2;
  
  function destockage (p_id_produit number, p_num_ordre varchar2, p_ordre varchar2, p_methode varchar2 ) return varchar2;
  
  function Annuler_destockage (p_id_produit number, p_num_ordre varchar2 ) return varchar2;
  
  function Annuler_destockage_demande (p_id_demande number ) return varchar2;
  
  function  liberer_lots (p_id_demande number) return varchar2;
  
  function  liberer_lots_pour_cloture (p_id_demande number) return varchar2;
  
  function mvt_Sortie_stock (p_id_demande number) return varchar2;
  
  function destockage_lott (p_id_lot number, p_qte number, p_num_ordre varchar2) return varchar2;
  
  function condition_cloture_sortie(p_id_demande number) return varchar2;

  procedure init_statut(p_id_demande number);
  
   function controle_preparation(p_id_demande number) return varchar2;
  
END STOCK_DEMANDE_SORTIE_PKG;
/

