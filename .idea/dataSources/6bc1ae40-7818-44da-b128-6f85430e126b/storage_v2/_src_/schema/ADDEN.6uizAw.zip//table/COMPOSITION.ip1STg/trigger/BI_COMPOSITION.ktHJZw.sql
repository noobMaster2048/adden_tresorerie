create trigger BI_COMPOSITION
    before insert
    on COMPOSITION
    for each row
begin   
  if :NEW."ID_COMPO" is null then 
    select "COMPOSITION_SEQ".nextval into :NEW."ID_COMPO" from sys.dual; 
  end if; 
end;

/

