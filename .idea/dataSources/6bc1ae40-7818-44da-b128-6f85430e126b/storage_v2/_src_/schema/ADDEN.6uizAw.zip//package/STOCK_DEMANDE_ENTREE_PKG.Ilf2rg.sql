create PACKAGE STOCK_DEMANDE_ENTREE_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
  function creer_entete_demande(p_date_demande date, p_id_frs number, p_designation varchar2) return varchar2;
  
  procedure creer_detail_demande (p_id_produit number, p_quantite number, p_num_proforma varchar2);
  
  function get_num_proforma(p_prefixe varchar2,p_taille number,p_date date) return varchar2;
  function get_num_BC(p_prefixe varchar2,p_taille number,p_date date) return varchar2;
 function get_num_BL(p_prefixe varchar2,p_taille number,p_date date) return varchar2;
  procedure generer_lot(p_id_produit number, p_num_bl varchar2, p_nbre_lot number, p_qte number default null);

procedure mvt_Entree_stock (p_num_dem number) ;

procedure init_statut(p_id_demande number);

function controle_proforma(p_id_demande number) return varchar2;

function controle_preparation(p_id_demande number) return varchar2;



END STOCK_DEMANDE_ENTREE_PKG;
/

