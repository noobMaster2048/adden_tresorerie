create PACKAGE BODY PARAMETRE_PKG AS

  function get_paramvalue_by_date(p_code in varchar2, p_date in date default sysdate) return varchar2 AS
  BEGIN
    -- TODO : implémentation requise pour function PARAMETRE_PKG.get_paramvalue_by_date
    for par in (
        select v.* 
        from parametres p ,
             valeurs_parametres v
        where p.id_parametre=v.id_parametre
        and  (    ( p_date between v.start_date and v.end_date ) 
               or ( p_date >= v.start_date and v.end_date is null )   
            )
        and   p.nature!='LOV'
        and   p.libelle = p_code
        )
    loop
    
    return par.valeur;
    
    end loop;
    
    RETURN NULL;
  END get_paramvalue_by_date;

  function test_chevauche(p_code in varchar2, p_date in date default sysdate)return boolean  AS
  BEGIN
    -- TODO : implémentation requise pour function PARAMETRE_PKG.test_chevauche
    RETURN true;
  END test_chevauche;

  function get_natureparam(p_code in varchar2) return varchar2  AS
  BEGIN
    -- TODO : implémentation requise pour function PARAMETRE_PKG.get_natureparam
        for par in (
        select p.* 
        from parametres p 
        where 1=1
        and p.id_parametre = p_code
        and trim(p.nature)='LOV'
        )
        loop
        
         return par.nature ;
        end loop;
        
    RETURN NULL;
  END get_natureparam;
  
  function get_typeparam(p_code in varchar2, p_nature in varchar2) return varchar2 as
  begin 
  
    -- TODO : implémentation requise pour function PARAMETRE_PKG.get_typeparam
        for par in (
        select p.* 
        from parametres p 
        where 1=1
        and p.id_parametre = p_code
        and p.nature = p_nature
        )
        loop
        
         return par.type ;
        end loop;  
  end get_typeparam ;

  function get_libellelov_bycode(p_code in varchar2, p_code_value in varchar2) return varchar2 AS
  BEGIN
    -- TODO : implémentation requise pour function PARAMETRE_PKG.get_libellelov_bycode
    for par in (
        select v.* 
        from parametres p ,
             valeurs_parametres v
        where p.id_parametre=v.id_parametre
        and   trim(p.nature)='LOV'
        and   p.libelle = p_code
        and   v.code_valeur = p_code_value
        )
    loop
    
    return par.valeur;
    
    end loop;    
    RETURN NULL;
  END get_libellelov_bycode;

END PARAMETRE_PKG;
/

