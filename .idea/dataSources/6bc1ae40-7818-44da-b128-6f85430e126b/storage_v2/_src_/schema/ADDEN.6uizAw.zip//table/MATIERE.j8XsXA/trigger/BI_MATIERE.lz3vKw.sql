create trigger BI_MATIERE
    before insert
    on MATIERE
    for each row
begin   
  if :NEW."ID_MAT" is null then 
    select "MATIERE_SEQ".nextval into :NEW."ID_MAT" from sys.dual; 
  end if; 
end;

/

