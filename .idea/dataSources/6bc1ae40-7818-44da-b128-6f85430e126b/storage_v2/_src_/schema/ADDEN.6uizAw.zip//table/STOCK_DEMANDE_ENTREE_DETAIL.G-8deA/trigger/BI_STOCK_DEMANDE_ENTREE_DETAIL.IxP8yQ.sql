create trigger BI_STOCK_DEMANDE_ENTREE_DETAIL
    before insert
    on STOCK_DEMANDE_ENTREE_DETAIL
    for each row
begin   
  if :NEW."ID_DM_ENTREE_DETAIL" is null then 
    select "STOCK_DEMANDE_ENTREE_DETAIL_SEQ".nextval into :NEW."ID_DM_ENTREE_DETAIL" from sys.dual; 
  end if; 
  :NEW.STATUT :='Y';
end;
/

