create trigger BI_CLASSE
    before insert
    on CLASSE
    for each row
begin   
  if :NEW."ID_CLASS" is null then 
    select "CLASSE_SEQ".nextval into :NEW."ID_CLASS" from sys.dual; 
  end if; 
end;

/

