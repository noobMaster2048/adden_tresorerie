create trigger BI_ELEVE
    before insert
    on ELEVE
    for each row
begin   
  if :NEW."ID_ELEV" is null then 
    select "ELEVE_SEQ".nextval into :NEW."ID_ELEV" from sys.dual; 
  end if; 
end;

/

