create PACKAGE STOCK_INVENTAIRES_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
function  creer_inventaire(p_intitutle varchar2, p_date date) return number;

function creer_detail_Inventaire (p_id_inv number) return number;

procedure modifier_stock_lot(p_id_lot number, ecart number);

procedure insert_mvt_stock(p_id_lot number, p_id_inv number,p_date_inv date, p_lib_inv varchar2,  p_id_produit number, p_type varchar2, p_quantite number) ;

procedure cloture_inventaire (p_id_inv number);

END STOCK_INVENTAIRES_PKG;
/

