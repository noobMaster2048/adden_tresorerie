create trigger BI_TEST_BUDGET
    before insert
    on TEST_BUDGET
    for each row
begin   
  if :NEW."ID_TEST" is null then 
    select "TEST_BUDGET_SEQ".nextval into :NEW."ID_TEST" from sys.dual; 
  end if; 
end;

/

