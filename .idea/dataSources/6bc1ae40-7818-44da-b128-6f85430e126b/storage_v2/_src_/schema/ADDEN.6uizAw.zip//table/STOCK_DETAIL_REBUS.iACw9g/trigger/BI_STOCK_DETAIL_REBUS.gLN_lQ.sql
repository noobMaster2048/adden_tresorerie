create trigger BI_STOCK_DETAIL_REBUS
    before insert
    on STOCK_DETAIL_REBUS
    for each row
begin   
  if :NEW."DETAIL_REBUS_ID" is null then 
    select "STOCK_DETAIL_REBUS_SEQ".nextval into :NEW."DETAIL_REBUS_ID" from sys.dual; 
  end if; 
end;
/

