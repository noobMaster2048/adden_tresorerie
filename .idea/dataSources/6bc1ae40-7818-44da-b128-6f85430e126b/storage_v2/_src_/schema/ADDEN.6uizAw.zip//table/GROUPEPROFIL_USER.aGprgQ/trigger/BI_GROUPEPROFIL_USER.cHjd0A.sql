create trigger BI_GROUPEPROFIL_USER
    before insert
    on GROUPEPROFIL_USER
    for each row
begin   
  if :NEW."ID" is null then 
    select "GROUPEPROFIL_USER_SEQ".nextval into :NEW."ID" from sys.dual; 
  end if; 
end;

/

