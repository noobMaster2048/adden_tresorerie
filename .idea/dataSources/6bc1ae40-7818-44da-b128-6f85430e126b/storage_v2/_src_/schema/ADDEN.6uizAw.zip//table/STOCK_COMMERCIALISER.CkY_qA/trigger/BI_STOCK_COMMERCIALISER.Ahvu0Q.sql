create trigger BI_STOCK_COMMERCIALISER
    before insert
    on STOCK_COMMERCIALISER
    for each row
begin   
  if :NEW."ID" is null then 
    select "STOCK_COMMERCIALISER_SEQ1".nextval into :NEW."ID" from sys.dual; 
  end if; 
end;
/

