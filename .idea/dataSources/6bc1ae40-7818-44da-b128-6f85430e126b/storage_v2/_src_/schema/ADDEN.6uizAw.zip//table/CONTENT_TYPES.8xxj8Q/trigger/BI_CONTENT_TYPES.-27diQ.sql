create trigger BI_CONTENT_TYPES
    before insert
    on CONTENT_TYPES
    for each row
begin   
  if :NEW."ID_CONTENT" is null then 
    select "CONTENT_TYPES_SEQ".nextval into :NEW."ID_CONTENT" from sys.dual; 
  end if; 
end;

/

