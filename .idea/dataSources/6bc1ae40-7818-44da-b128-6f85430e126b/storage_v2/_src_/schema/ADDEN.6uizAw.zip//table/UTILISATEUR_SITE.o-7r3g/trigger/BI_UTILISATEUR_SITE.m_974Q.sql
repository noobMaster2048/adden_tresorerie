create trigger BI_UTILISATEUR_SITE
    before insert
    on UTILISATEUR_SITE
    for each row
begin   
  if :NEW."ID_USER_SITE" is null then 
    select "UTILISATEUR_SITE_SEQ".nextval into :NEW."ID_USER_SITE" from sys.dual; 
  end if; 
end;

/

