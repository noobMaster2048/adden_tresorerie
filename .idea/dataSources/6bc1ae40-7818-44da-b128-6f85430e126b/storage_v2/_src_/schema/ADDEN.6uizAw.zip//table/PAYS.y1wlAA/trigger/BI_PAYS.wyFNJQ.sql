create trigger BI_PAYS
    before insert
    on PAYS
    for each row
begin   
  if :NEW."ID_PAYS" is null then 
    select "PAYS_SEQ".nextval into :NEW."ID_PAYS" from sys.dual; 
  end if; 
end;

/

