create trigger BI_PARENT
    before insert
    on PARENT
    for each row
begin   
  if :NEW."ID_PARENT" is null then 
    select "PARENT_SEQ".nextval into :NEW."ID_PARENT" from sys.dual; 
  end if; 
end;

/

