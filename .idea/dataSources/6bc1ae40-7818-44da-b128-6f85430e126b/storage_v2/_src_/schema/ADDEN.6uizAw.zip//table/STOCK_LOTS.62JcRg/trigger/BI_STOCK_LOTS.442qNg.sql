create trigger BI_STOCK_LOTS
    before insert
    on STOCK_LOTS
    for each row
begin   
  if :NEW."ID_LOT" is null then 
    select "STOCK_LOTS_SEQ".nextval into :NEW."ID_LOT" from sys.dual; 
  end if; 
end;

/

