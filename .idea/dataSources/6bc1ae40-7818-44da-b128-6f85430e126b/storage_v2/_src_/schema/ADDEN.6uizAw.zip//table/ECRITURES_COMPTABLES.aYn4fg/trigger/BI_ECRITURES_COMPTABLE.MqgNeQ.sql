create trigger BI_ECRITURES_COMPTABLE
    before insert
    on ECRITURES_COMPTABLES
    for each row
begin   
  if :NEW."ID_ECRITURE" is null then 
    select "ECRITURES_COMPTABLE_SEQ".nextval into :NEW."ID_ECRITURE" from sys.dual; 
  end if; 
end;

/

