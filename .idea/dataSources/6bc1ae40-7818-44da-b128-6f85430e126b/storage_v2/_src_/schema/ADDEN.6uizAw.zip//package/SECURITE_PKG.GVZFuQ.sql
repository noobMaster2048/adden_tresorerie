create PACKAGE                       SECURITE_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  /*
  Cette fonction permet de recuperer les groupes d'un utilisateur
  au format :GROUPE1:GROUPE2:GROUPE3:
  */
  function get_usergroupe(p_user in varchar2, p_date in date default sysdate) return varchar2 ;
    /*
  Cette fonction permet de recuperer les profiles d'un utilisateur
  au format :PROFILE1:PROFILE2:PROFILE3:
  */
  function get_userprofile(p_user in varchar2, p_date in date default sysdate) return varchar2 ;
  
  /*
  Cette fonction permet de changer le mot d'un utilisateur
  */
  function set_password(p_user in varchar2 , p_newpwd in varchar2, p_ancienpwd in varchar2) return varchar2 ;
  
  
  /*
  Cette fonction permet de tester l'appartenance à un groupe d'un utilisateur
  */  
   function is_usergroupe(p_user in varchar2, p_groupe in varchar2) return boolean ;
   
   
  /*
  Cette fonction permet de tester l'appartenance à un profile d'un utilisateur
  */    
   function is_userprofile(p_user in varchar2, p_profile in varchar2) return boolean ;
  -- function is_usersite(p_user in varchar2, p_site in number) return boolean ;
 
   /*
  Cette fonction permet de tester l'appartenance à un site d'un utilisateur
  
  ramene une valeur supérieur à 0 si l'utilisateur est affecter au site. Sinon elle 
  ramene 0  si l'utilisateur n'appartient pas au site
  */   
   function is_usersite(p_user in varchar2, p_site in number) return number ;
   
   
   function isadmin(p_user in varchar2) return boolean ;
   

END SECURITE_PKG;
/

