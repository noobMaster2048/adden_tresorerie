create package PERIODE_PKG as

 PROCEDURE genere_periode(p_exercice in varchar2);
 
 function isrecordable( p_exercice in number , p_statut in varchar2) return boolean ;

end PERIODE_PKG;
/

