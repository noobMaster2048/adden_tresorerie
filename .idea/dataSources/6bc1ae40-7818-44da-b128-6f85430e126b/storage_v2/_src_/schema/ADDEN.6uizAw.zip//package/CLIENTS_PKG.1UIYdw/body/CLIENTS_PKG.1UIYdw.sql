create PACKAGE BODY CLIENTS_PKG AS

function init_values( 
    v_id_client number default global_pkg.number_default_v
    , v_sigle varchar2 default global_pkg.varchar_default_v
    , v_raison_sociale varchar2 default global_pkg.varchar_default_v
    , v_id_pays number default global_pkg.number_default_v
    , v_ville varchar2 default global_pkg.varchar_default_v
    , v_start_date date default global_pkg.date_default_v
    , v_end_date date default global_pkg.date_default_v
    , v_statut varchar2 default global_pkg.varchar_default_v
    , v_insert_date date default global_pkg.date_default_v
    , v_insert_number number default global_pkg.number_default_v
    , v_update_date date default global_pkg.date_default_v
    , v_update_number number default global_pkg.number_default_v
    ) return clients_v%rowtype
    is
        clients_rec clients_v%rowtype;
    begin
            clients_rec := null;
            clients_rec.id_client := v_id_client;
            clients_rec.sigle := v_sigle;
            clients_rec.raison_sociale := v_raison_sociale;
            clients_rec.id_pays := v_id_pays;
            clients_rec.start_date := v_start_date;
            clients_rec.end_date :=v_end_date;
            clients_rec.statut :=v_statut;
            clients_rec.insert_date :=v_insert_date;
            clients_rec.insert_user := v_insert_number;
            clients_rec.update_date := v_update_date;
            clients_rec.update_user := v_update_number;
            
            return clients_rec;
    end init_values ;
    
procedure init_record_rows( rec in out clients_v%rowtype, rec_init clients_v%rowtype)
as 

begin
    if rec.id_client = global_pkg.number_default_v then
        rec.id_client := rec_init.id_client;
    end if;
     if rec.sigle = global_pkg.varchar_default_v then
        rec.sigle := rec_init.sigle;
    end if;
     if rec.raison_sociale = global_pkg.varchar_default_v then
        rec.raison_sociale := rec_init.raison_sociale;
    end if;
     if rec.id_pays = global_pkg.number_default_v then
        rec.id_pays := rec_init.id_pays;
    end if;
    if rec.ville = global_pkg.varchar_default_v then
        rec.ville := rec_init.ville;
    end if;
     if rec.start_date = global_pkg.date_default_v then
        rec.start_date := rec_init.start_date;
    end if;
     if rec.end_date = global_pkg.date_default_v then
        rec.end_date := rec_init.end_date;
    end if;
     if rec.statut = global_pkg.varchar_default_v then
        rec.statut := rec_init.statut;
    end if;
     if rec.insert_date = global_pkg.date_default_v then
        rec.insert_date := rec_init.insert_date;
    end if;
     if rec.insert_user = global_pkg.number_default_v then
        rec.insert_user := rec_init.insert_user;
    end if;
     if rec.update_date = global_pkg.date_default_v then
        rec.update_date := rec_init.update_date;
    end if;
     if rec.update_user = global_pkg.number_default_v then
        rec.update_user := rec_init.update_user;
    end if;

end init_record_rows;
    
procedure inserter( rec in out nocopy clients%rowtype)
is
    clients_rec clients_v%rowtype;
begin
    clients_rec := null;    
    init_record_rows (rec, clients_rec);
    rec.insert_date := sysdate;
    rec.insert_user := apex_util.get_user_id(v('APP_USER'));
    rec.update_date := null;
    rec.update_user := null;    
    select clients_seq.nextval into rec.id_client from dual;    
    insert into clients_v values rec;
end inserter;

procedure updater ( rec in out nocopy clients%rowtype)
is
    clients_rec clients_v%rowtype;
 begin
    clients_rec:=null;
 begin
     select * into clients_rec from clients_v where id_client = rec.id_client;
     exception
        when no_data_found then null;
     end;
     init_record_rows (rec, clients_rec);
     rec.update_date := sysdate;
    rec.update_user := apex_util.get_user_id(v('APP_USER')); 
    update clients_v set row = rec where id_client = rec.id_client;
end updater;

procedure deleter (v_id_client number default global_pkg.number_default_v)
is 
       clients_rec clients_v%rowtype;
begin
    delete clients_v where id_client = v_id_client;
end deleter;


END CLIENTS_PKG;
/

