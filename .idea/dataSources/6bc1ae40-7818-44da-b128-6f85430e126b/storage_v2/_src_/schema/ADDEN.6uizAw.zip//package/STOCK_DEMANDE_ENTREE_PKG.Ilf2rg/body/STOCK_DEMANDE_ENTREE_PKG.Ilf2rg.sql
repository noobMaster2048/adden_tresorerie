create PACKAGE BODY STOCK_DEMANDE_ENTREE_PKG AS


function get_num_proforma(p_prefixe varchar2,p_taille number,p_date date)  return varchar2
is
l_numbre number;
l_nbre_part varchar2(10);
l_num varchar2(20);
begin

select count(id_dm_entree) into l_numbre
from stock_demande_entree_v
where to_char(date_demande,'dd/mm/yyyy') = to_char(p_date,'dd/mm/yyyy');

l_nbre_part := LPAD( to_char(l_numbre+1),  p_taille , '0' );

return p_prefixe || '_' || l_nbre_part || '_' || to_char(p_date, 'ddmmyy');

end;

function get_num_BC(p_prefixe varchar2,p_taille number,p_date date)  return varchar2
is
l_numbre number;
l_nbre_part varchar2(10);
l_num varchar2(20);
begin

select count(id_dm_entree) into l_numbre
from stock_demande_entree_v
where to_char(DATE_BON_COMMANDE,'dd/mm/yyyy') = to_char(p_date,'dd/mm/yyyy');

l_nbre_part := LPAD( to_char(l_numbre+1),  p_taille , '0' );

return p_prefixe || '_' || l_nbre_part || '_' || to_char(p_date, 'ddmmyy');

end;


function get_num_BL(p_prefixe varchar2,p_taille number,p_date date)  return varchar2
is
l_numbre number;
l_nbre_part varchar2(10);
l_num varchar2(20);
begin

select count(id_dm_entree) into l_numbre
from stock_demande_entree_v
where to_char(DATE_LIVRAISON,'dd/mm/yyyy') = to_char(p_date,'dd/mm/yyyy');

l_nbre_part := LPAD( to_char(l_numbre+1),  p_taille , '0' );

return p_prefixe || '_' || l_nbre_part || '_' || to_char(p_date, 'ddmmyy');

end;

function creer_entete_demande(p_date_demande date, p_id_frs number, p_designation varchar2) return varchar2
is
 p_record stock_demande_entree_v%rowtype;
 p_id_demande varchar2(50);
begin
        
        p_record.id_fournisseur := p_id_frs;
        p_record.date_demande := p_date_demande;
        p_record.intitule_demande := p_designation;
        p_record.num_proforma := get_num_proforma( 'DEV', 3, p_date_demande) ;
        p_record.statut := 'STOCK_E_DRAFT';
     select stock_demande_entree_seq.nextval into    p_record.ID_DM_ENTREE  from dual;
     p_id_demande := p_record.num_proforma ;
     begin
        insert into stock_demande_entree_v values p_record;
     exception when others then
            return null;
     end;
     return p_id_demande;
end ;

  procedure creer_detail_demande (p_id_produit number, p_quantite number, p_num_proforma varchar2)
  is
 p_record stock_demande_entree_detail_v%rowtype;
  
  begin 
  
  
  
  
  if p_id_produit is not null then
    for enr in (select * from stock_demande_entree_v where num_proforma = p_num_proforma) loop
    
    delete from stock_demande_entree_detail_v where id_dm_entree = enr.id_dm_entree and id_produit = p_id_produit;
    commit;
    
        p_record.id_produit := p_id_produit;
        p_record.qte_demande := to_number(p_quantite);
        p_record.id_dm_entree :=to_number(enr.id_dm_entree);
      
    
    begin
        insert into stock_demande_entree_detail_v values p_record;
     exception when others then
         null;
     end;
    end loop;
  end if;
  end;
  
  procedure generer_lot(p_id_produit number, p_num_bl varchar2, p_nbre_lot number, p_qte number default null)
  is
  l_qte number;
  l_qte_lot number;
  l_qte_lot_rest number;
  l_rest number;
  l_rec stock_lots_v%rowtype;
  begin
  if p_nbre_lot > 0 then
   delete from stock_lots_v where num_bl = p_num_bl and id_produit = p_id_produit;
   for enr in (select det.*, ent.date_livraison from stock_demande_entree_detail_v det, stock_demande_entree_v ent
                        where ent.id_dm_entree= det.id_dm_entree  and ent.num_bon_livraison=p_num_bl and det.id_produit = p_id_produit) loop
                        if p_qte is null then l_qte := enr.qte_livre; end if;
                        l_qte_lot := FLOOR(l_qte / p_nbre_lot );
                        l_qte_lot_rest := mod(l_qte , p_nbre_lot );
                        l_rest := round(l_qte_lot_rest/ p_nbre_lot);
                        for i in 1..p_nbre_lot loop
                            l_rec := null;
                            l_rec.designation := 'lot N°' || to_char(i) ||  'du BL n° ' || p_num_bl;
                            l_rec.date_lot := enr.date_livraison;
                            l_rec.id_produit := p_id_produit;
                            l_rec.num_bl := p_num_bl;
                            l_rec.statut :='E';
                            if l_qte_lot_rest >=1 then
                             l_rec.quantite := l_qte_lot +l_rest;
                             else
                                    l_rec.quantite := l_qte_lot;
                             end if;
                            insert into stock_lots_v values l_rec;
                            l_qte_lot_rest := l_qte_lot_rest -1;
                        end loop;
                        
    end loop;
  end if;
  end;

procedure mvt_Entree_stock (p_num_dem number) 
is
l_mvt_stock STOCK_MVT_PRODUIT_v%rowtype;
begin

for dem in (select * from stock_demande_entree_v where id_dm_entree = p_num_dem) loop
  for bl in (select * from stock_lots_v where NUM_BL = dem.NUM_BON_LIVRAISON) loop
        l_mvt_stock := null;
        l_mvt_stock.DATE_MVT:= dem.DATE_LIVRAISON;
        l_mvt_stock.ID_PRODUIT := bl.ID_PRODUIT;
        l_mvt_stock.ID_lieu:= bl.ID_LIEU;
        l_mvt_stock.ID_TYPE_MVT := 'E';
        l_mvt_stock.ID_DEMANDE := dem.ID_DM_ENTREE;
        l_mvt_stock.ID_LOT := bl.ID_LOT;
        l_mvt_stock.qte := bl.QUANTITE;
        l_mvt_stock.designation := bl.DESIGNATION;
        l_mvt_stock.id_fournisseur := dem.ID_FOURNISSEUR;
        
        insert into STOCK_MVT_PRODUIT_v values l_mvt_stock;
        
    update stock_lots_v set statut = null where id_lot = bl.ID_LOT;
        
  end loop;
end loop;
end;


procedure init_statut(p_id_demande number)
is
begin

begin

   update STOCK_DEMANDE_ENTREE_DETAIL_V set statut = 'Y' , observations = null where ID_DM_ENTREE= p_id_demande;
   commit;
   
exception when others then
    null;
end;

end;

function controle_preparation(p_id_demande number) return varchar2
is
l_message varchar2(320);
l_nbre number;


begin

return null;
 select count(ID_DM_ENTREE) into l_nbre from STOCK_DEMANDE_ENTREE_DETAIL_V where ID_DM_ENTREE = p_id_demande;
 if l_nbre =0 then 
    raise_application_error(-20208, 'Vous n''avez pas ajouté de produits à commander !');
 end if;
end ;

function controle_proforma(p_id_demande number) return varchar2
is
l_message varchar2(320);


begin
    for enr in (select * from STOCK_DEMANDE_ENTREE_V where  ID_DM_ENTREE = p_id_demande ) loop
            if enr.NUM_BON_COMMANDE is null then 
                    raise_application_error(-20200, 'Vous n''avez pas generé le numéro de Bon de Commande !');
            end if;
            for det in (select * from STOCK_DEMANDE_ENTREE_DETAIL_V where ID_DM_ENTREE = p_id_demande and QTE_DISPONIBLE is null) loop
                       raise_application_error(-20209, 'Vous n''avez pas saisi toutes les quantité proforma !');
            end loop;
             for det in (select * from STOCK_DEMANDE_ENTREE_DETAIL_V where ID_DM_ENTREE = p_id_demande and PRIX_PROFORMA is null) loop
                       raise_application_error(-20209, 'Vous n''avez pas saisi tous les prix proforma !');
            end loop;
    end loop;
    
    return null;

end;



END STOCK_DEMANDE_ENTREE_PKG;
/

