create PACKAGE FICHIER_COMPTA_IMPORT_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

 procedure chargement_fichier_comptable
  (
    p_fichier varchar2
  );
  
  function Get_info (p_numero_compte varchar2, p_date varchar2, p_info varchar2, p_message in out varchar2) return varchar2;
  
procedure transformation (p_nom_fichier varchar2) ;
 
 procedure  transformer ( p_row in out LIGNES_COMPTA_V%rowtype) ;
 
  procedure supprimer_fichier (p_nom_fichier varchar2);
  
  function verif_import_fichier( p_nom_fichier varchar2) return number;
  
  PROCEDURE importation (p_nom_fichier varchar2) ;

END FICHIER_COMPTA_IMPORT_PKG;
/

