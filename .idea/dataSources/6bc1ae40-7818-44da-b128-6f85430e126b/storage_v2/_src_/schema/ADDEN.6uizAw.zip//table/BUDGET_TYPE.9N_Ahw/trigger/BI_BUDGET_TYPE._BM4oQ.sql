create trigger BI_BUDGET_TYPE
    before insert or update
    on BUDGET_TYPE
    for each row
begin   
 /* if inserting and :NEW."ID_BUDGET_RUBRIQUE" is null then 
    select "BUDGET_RUBRIQUES_SEQ".nextval into :NEW."ID_BUDGET_RUBRIQUE" from sys.dual; 
  end if;*/
  if inserting then
        :new.INSERT_USER := v('USER');
        :new.INSERT_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
    if updating then
        :new.UPDATE_USER := v('USER');
        :new.UPDATE_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
end;
/

