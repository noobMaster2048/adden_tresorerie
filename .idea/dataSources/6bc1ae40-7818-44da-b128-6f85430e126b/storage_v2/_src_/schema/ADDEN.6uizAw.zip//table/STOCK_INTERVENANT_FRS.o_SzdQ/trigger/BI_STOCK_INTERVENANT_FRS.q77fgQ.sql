create trigger BI_STOCK_INTERVENANT_FRS
    before insert
    on STOCK_INTERVENANT_FRS
    for each row
begin   
  if :NEW."ID_INTERVENANT" is null then 
    select "STOCK_INTERVENANT_FRS_SEQ".nextval into :NEW."ID_INTERVENANT" from sys.dual; 
  end if; 
end;

/

