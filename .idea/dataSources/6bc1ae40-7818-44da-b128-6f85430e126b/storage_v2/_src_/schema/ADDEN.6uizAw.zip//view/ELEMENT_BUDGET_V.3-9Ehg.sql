create view ELEMENT_BUDGET_V as
select  'RUB' NIVEL, ent.id_exercice exo,
ent.id_exercice ||rub.nature || ent.id_site || rub.id_budget_rubrique ID_ELEMENT ,
         ent.id_exercice ||rub.nature || ent.id_site CODE_ELEMENT ,
         rub.designation VALEUR_ELEMENT
--, prev.janvier
, sum(prev.janvier) janvier
, sum(prev.fevrier) fevrier
, sum(prev.mars) mars
, sum(prev.avril) avril
, sum(prev.mai) mai
, sum(prev.juin) juin
, sum(prev.juillet) juillet
, sum(prev.aout) aout
, sum(prev.septembre) septembre
, sum(prev.octobre) octobre
, sum(prev.novembre) novembre
, sum(prev.decembre) decembre
, sum(nvl(prev.janvier ,0)
+nvl( prev.fevrier ,0)
+nvl(prev.mars ,0)
+nvl(prev.avril ,0)
+nvl(prev.mai ,0)
+nvl(prev.juin ,0)
+nvl(prev.juillet ,0)
+nvl(prev.aout ,0)
+nvl(prev.septembre ,0)
+nvl(prev.octobre ,0)
+nvl(prev.novembre ,0)
+nvl(prev.decembre ,0)
) total
from
budget_previsions_siege_v prev, budget_previsions_entete_v ent, budget_rubriques_v rub--, budget_type_v typ
where ent.id_prevision_entete = prev.id_prevision_entete
--and ent.id_exercice = :P82_EXERCICE
and prev.id_rubrique= rub.id_budget_rubrique
group by   'RUB' ,
ent.id_exercice ,
ent.id_exercice ||rub.nature || ent.id_site || rub.id_budget_rubrique  ,
         ent.id_exercice ||rub.nature || ent.id_site  ,
         rub.designation

-- site
union
select  'SIT' nivel ,ent.id_exercice exo,
ent.id_exercice ||rub.nature || ent.id_site  ID_ELEMENT ,
         ent.id_exercice ||rub.nature  CODE_ELEMENT ,
        to_char( sit.DESIGNATION) VALEUR_ELEMENT
--, prev.janvier
, sum(prev.janvier) janvier
, sum(prev.fevrier) fevrier
, sum(prev.mars) mars
, sum(prev.avril) avril
, sum(prev.mai) mai
, sum(prev.juin) juin
, sum(prev.juillet) juillet
, sum(prev.aout) aout
, sum(prev.septembre) septembre
, sum(prev.octobre) octobre
, sum(prev.novembre) novembre
, sum(prev.decembre) decembre
, sum(nvl(prev.janvier ,0)
+nvl( prev.fevrier ,0)
+nvl(prev.mars ,0)
+nvl(prev.avril ,0)
+nvl(prev.mai ,0)
+nvl(prev.juin ,0)
+nvl(prev.juillet ,0)
+nvl(prev.aout ,0)
+nvl(prev.septembre ,0)
+nvl(prev.octobre ,0)
+nvl(prev.novembre ,0)
+nvl(prev.decembre ,0)
) total
from
budget_previsions_siege_v prev, budget_previsions_entete_v ent, budget_rubriques_v rub, site_v sit
where ent.id_prevision_entete = prev.id_prevision_entete
--and ent.id_exercice = :P82_EXERCICE
and prev.id_site=sit.id_site
and prev.id_rubrique= rub.id_budget_rubrique
group by 'SIT',
 ent.id_exercice ,
ent.id_exercice ||rub.nature || ent.id_site   ,
         ent.id_exercice ||rub.nature   ,
             to_char( sit.DESIGNATION) --ent.id_site 
--nature
union
select  'NAT' nivel, ent.id_exercice exo,
ent.id_exercice ||rub.nature   ID_ELEMENT ,
         to_char(ent.id_exercice)   CODE_ELEMENT ,
        decode( rub.nature,'CH','CHARGES','PRODUITS') VALEUR_ELEMENT
--, prev.janvier
, sum(decode ( rub.nature, 'PR',prev.janvier, prev.janvier*(-1) )) janvier
, sum(decode ( rub.nature, 'PR',prev.fevrier, prev.fevrier*(-1) )) fevrier
, sum(decode ( rub.nature, 'PR',prev.mars, prev.mars*(-1) )) mars
, sum(decode ( rub.nature, 'PR',prev.avril, prev.avril*(-1) )) avril
, sum(decode ( rub.nature, 'PR',prev.mai, prev.mai*(-1) )) mai
, sum(decode ( rub.nature, 'PR',prev.juin, prev.juin*(-1) )) juin
, sum(decode ( rub.nature, 'PR',prev.juillet, prev.juillet*(-1) )) juillet
, sum(decode ( rub.nature, 'PR',prev.aout, prev.aout*(-1) )) aout
, sum(decode ( rub.nature, 'PR',prev.septembre, prev.septembre*(-1) )) septembre
, sum(decode ( rub.nature, 'PR',prev.octobre, prev.octobre*(-1) )) octobre
, sum(decode ( rub.nature, 'PR',prev.novembre, prev.novembre*(-1) )) novembre
, sum(decode ( rub.nature, 'PR',prev.decembre, prev.decembre*(-1) )) decembre
, sum(nvl(decode ( rub.nature, 'PR',prev.janvier, prev.janvier*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.fevrier, prev.fevrier*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.mars, prev.mars*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.avril, prev.avril*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.mai, prev.mai*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.juin, prev.juin*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.juillet, prev.juillet*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.aout, prev.aout*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.septembre, prev.septembre*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.octobre, prev.octobre*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.novembre, prev.novembre*(-1) ) ,0)
+nvl(decode ( rub.nature, 'PR',prev.decembre, prev.decembre*(-1) ) ,0)
) total
from
budget_previsions_siege_v prev, budget_previsions_entete_v ent, budget_rubriques_v rub--, budget_type_v typ
where ent.id_prevision_entete = prev.id_prevision_entete
--and ent.id_exercice = :P82_EXERCICE
and prev.id_rubrique= rub.id_budget_rubrique
group by 'NAT',
 ent.id_exercice ,
ent.id_exercice ||rub.nature    ,
         to_char(ent.id_exercice)     ,
         rub.nature 
-- exercice
union
select  'EXE' nivel,  ent.id_exercice exo,
to_char(ent.id_exercice)   ID_ELEMENT ,
         null CODE_ELEMENT ,-- to_char(ent.id_exercice )  CODE_ELEMENT ,
         to_char(ent.id_exercice) VALEUR_ELEMENT
--, prev.janvier
, sum(prev.janvier) janvier
, sum(prev.fevrier) fevrier
, sum(prev.mars) mars
, sum(prev.avril) avril
, sum(prev.mai) mai
, sum(prev.juin) juin
, sum(prev.juillet) juillet
, sum(prev.aout) aout
, sum(prev.septembre) septembre
, sum(prev.octobre) octobre
, sum(prev.novembre) novembre
, sum(prev.decembre) decembre
, sum(nvl(prev.janvier ,0)
+nvl( prev.fevrier ,0)
+nvl(prev.mars ,0)
+nvl(prev.avril ,0)
+nvl(prev.mai ,0)
+nvl(prev.juin ,0)
+nvl(prev.juillet ,0)
+nvl(prev.aout ,0)
+nvl(prev.septembre ,0)
+nvl(prev.octobre ,0)
+nvl(prev.novembre ,0)
+nvl(prev.decembre ,0)
) total
from
budget_previsions_siege_v prev, budget_previsions_entete_v ent, budget_rubriques_v rub--, budget_type_v typ
where ent.id_prevision_entete = prev.id_prevision_entete
--and ent.id_exercice = :P82_EXERCICE
and prev.id_rubrique= rub.id_budget_rubrique
group by  'EXE' , ent.id_exercice ,
  ent.id_exercice    ,        null    ,         ent.id_exercice
/

