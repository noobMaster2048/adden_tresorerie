create PACKAGE BODY FICHIER_COMPTA_IMPORT_PKG AS

procedure chargement_fichier_comptable
  (
    p_fichier varchar2
  )
  is
    i number := 2;
    l_message varchar2(2000);
    l_statut varchar2(5);
    l_rec_compta LIGNES_COMPTA_V%rowtype;
l_sql varchar2(2000);
  begin
    
   l_sql := ' truncate table  TMPFILE';
   execute immediate l_sql;
    commit;

    FILES_PKG.Chargement_fichier(P_FICHIER);
  --  delete LIGNES_COMPTA_V p;--- where p.dem_rpz_pens_id = p_dem_rpz_pens_id;

    for une_ligne in
    (
      select *
        from TMPFILE_V uf
       --where upper(trim(' ' from uf.column38)) <> 'PAIEMENT UNIQUE'
    order by numero_ligne
    )
    loop
      l_message := null;
      l_statut := null;
    --  l_current_user_id := ppyrt_gen_utilities_pkg.get_context('user_id');
   --   l_current_date := sysdate;

      i := i + 1;

     -- l_rec_compta.regime_retraite := replace_reg_rcpnc_2_rrpc(replace(une_ligne.column01,' '),replace(replace(une_ligne.column03,' '),'.'));
     -- l_rec_compta.matricule_crrae := nvl(replace(replace(une_ligne.column03,' '),'.'),replace(replace(une_ligne.column02,' '),'.'));
     
     --  l_rec_compta.id_piece:= UNE_LIGNE.column01;
  --     l_rec_compta.id_ligne:=  UNE_LIGNE.column02;
      l_rec_compta.designation_piece :=  UNE_LIGNE.column04;
      l_rec_compta.date_piece := une_ligne.column02;
      l_rec_compta.numero_compte := une_ligne.column01;
    --  l_rec_compta.id_exercice := une_ligne.column06;
   --   l_rec_compta.id_periode := une_ligne.column07;
    --  l_rec_compta.id_rubrique :=une_ligne.column08;
      l_rec_compta.debit := une_ligne.column05;
      l_rec_compta.credit := une_ligne.column06;
      l_rec_compta.sens := une_ligne.column07;
    --  l_rec_compta.numero_compte_general := une_ligne.column12;
      l_rec_compta.statut_chargement := 'OK';
      l_rec_compta.nom_fichier := P_FICHIER;
      l_rec_compta.date_fichier := systimestamp; --to_date(sysdate, 'DD/MM/YYYY HH:MI:ss');
    
      
      
      
      insert into LIGNES_COMPTA_V values l_rec_compta;

    end loop;

  end chargement_fichier_comptable;

 function Get_info (p_numero_compte varchar2, p_date varchar2, p_info varchar2, p_message in out varchar2) return varchar2
 is
 la_rubrique varchar2(200);
 le_compte varchar2(200);
 le_type_budget varchar2(200);
 lexercice varchar2(200);
 la_periode varchar2(200);
 le_compte_general varchar2(200);
 lid_entete_prevision varchar2(200);
 lid_prevision varchar2(200);
 l_message varchar2(2000);
 
 l_date date;
 begin
  if p_numero_compte is not null and p_date is not null then
  
        case p_info
                when 'RUBRIQUE' then
                    begin 
                            select ID_BUDGET_RUBRIQUE into la_rubrique from BUDGET_RUBRIQUES_V where NUMERO_COMPTE = p_numero_compte;
                    exception  when others then
                            p_message := p_message || ' - Aucun poste budgetaire associé au compte comptable';
                    end;
                return la_rubrique;
             when 'COMPTE' then
                     begin
                            select libelle into le_compte  from comptes_comptables_v where numero_compte=p_numero_compte;
                     exception when others then
                                p_message := p_message || ' - Compte comptable introuvable';
                     end;
             return le_compte;
             
              when 'TYPE_BUDGET' then
                begin 
                        select TYPE into le_type_budget from BUDGET_RUBRIQUES_V where NUMERO_COMPTE = p_numero_compte;
                exception  when others then
                        p_message := p_message || ' - problème lors de la recuperation de TYPE DE BUDGET dans la table des rubriques';
                end;
            return le_type_budget;
            when 'EXERCICE' then            
                begin
                    select exercice into lexercice from exercices_v 
                    where p_date between start_date and end_date
                    and statut = 'EXEC';
                exception when others then
                    p_message := p_message || ' - La date de la piece non incluse dans l exercice en cours d execution ';
                end;
            return lexercice;
            when 'PERIODE' then            
            begin
              select id_periode into la_periode from periodes_v where p_date between start_date and end_date and nature ='MOIS';
            exception when others then
                p_message := p_message || ' - problème lors de la recuperation de la PERIODE dans la table des Periodes';
            end;
            return la_periode;
            when 'COMPTE_G' then            
            begin
              select numero_compte_general into le_compte_general from comptes_comptables_v where numero_compte=p_numero_compte;
            exception when others then
                p_message := p_message || ' - probleme lors de la recuperation de NUMERO_COMPTE_GENERAL dans la table des Comptes comptables';
            end;
            return le_compte_general;     
            when 'ENTETE' then            
            begin
              select prev.id_prevision_entete into lid_entete_prevision
                    from budget_rubriques_v rub, budget_previsions_siege_v prev, budget_previsions_entete_v ent
                    where rub.numero_compte = p_numero_compte
                    and rub.id_budget_rubrique= prev.id_rubrique
                    and ent.id_prevision_entete=prev.id_prevision_entete
                  --  and ent.type = (  select TYPE  from BUDGET_RUBRIQUES_V where NUMERO_COMPTE = p_numero_compte)
                  AND GENERER_BUDGET.verif_rubrique_site(ent.id_site, rub.id_budget_rubrique) =1
                    and ent.id_exercice = ( select exercice from exercices_v where p_date between start_date and end_date);
            exception when others then
                p_message := p_message || ' - Prévison budugetaire introuvable';
            end;
            return lid_entete_prevision; 
             when 'PREVISION' then            
            begin
              select prev.ID_PREVISION into lid_prevision
                    from budget_rubriques_v rub, budget_previsions_siege_v prev, budget_previsions_entete_v ent
                    where rub.numero_compte = p_numero_compte
                    and rub.id_budget_rubrique= prev.id_rubrique
                    and ent.id_prevision_entete=prev.id_prevision_entete
                   -- and ent.type = (  select TYPE  from BUDGET_RUBRIQUES_V where NUMERO_COMPTE = p_numero_compte)
                   AND GENERER_BUDGET.verif_rubrique_site(ent.id_site, rub.id_budget_rubrique) =1
                    and ent.id_exercice = ( select exercice from exercices_v where p_date between start_date and end_date);
            exception when others then
                p_message := p_message || ' - ligne budugetaire introuvable';
            end;
            
            return lid_prevision;    
                
         end case;
  end if;
 end Get_info ;
 
procedure transformation (p_nom_fichier varchar2) 
is 
begin
for enr in (select * from lignes_compta_v 
                    where nom_fichier =p_nom_fichier
                    and statut_transformation is  null or statut_transformation <> 'OK' and STATUT_CHARGEMENT ='OK') loop
        transformer (enr) ;
        
        update LIGNES_COMPTA_V set row = enr where id_row= enr.id_row;
        
        
 end loop;
end transformation ;
 
 procedure  transformer ( p_row in out LIGNES_COMPTA_V%rowtype) 
 is
 l_message varchar2(2000) := null;
 l_id_rubrique number;
 l_type_rubrique varchar2(200);
 l_exercice number;
 l_periode number;
 l_compte varchar2(200);
 l_budget number;
 l_date date;
 l_montant number;
 begin
 /*
  p_row.numero_compte := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'COMPTE'
                                                            , p_message => l_message);
 
 */
 begin 
    l_date := to_date(p_row.date_piece,'DD/MM/YYYY');
  exception when others then
      l_message := ' Probleme de conversion de la date';
  end;
  if p_row.numero_compte is null then
          l_message := l_message || ' Numero de compte non renseigné';
end if;

 if l_message is  null then 
          l_compte := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                                    , p_date => p_row.DATE_PIECE
                                                                    ,p_info => 'COMPTE'
                                                                    , p_message => l_message);
         if l_message is  null then
                 p_row.id_rubrique      := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                                    , p_date => p_row.DATE_PIECE
                                                                    ,p_info => 'RUBRIQUE'
                                                                    , p_message => l_message);                          
                            
         end if;
         p_row.ID_EXERCICE := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                                    , p_date => p_row.DATE_PIECE
                                                                    ,p_info => 'EXERCICE'
                                                                    , p_message => l_message); 
         
            if l_message is  null then    
                                   p_row.ID_PREVISION_ENTETE := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'ENTETE'
                                                            , p_message => l_message);      
                                   p_row.ID_PREVISION := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'PREVISION'
                                                            , p_message => l_message);             
            end if;
                                                                    
 end if;

                                
 
 /*
    p_row.id_rubrique := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'RUBRIQUE'
                                                            , p_message => l_message);
     p_row.TYPE_BUDGET := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'TYPE_BUDGET'
                                                            , p_message => l_message);
       p_row.ID_EXERCICE := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'EXERCICE'
                                                            , p_message => l_message); 
     p_row.ID_PERIODE := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'PERIODE'
                                                            , p_message => l_message); 
                                                            
      p_row.NUMERO_COMPTE_GENERAL := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'COMPTE_G'
                                                            , p_message => l_message); 
      p_row.ID_PREVISION_ENTETE := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'ENTETE'
                                                            , p_message => l_message);      
     p_row.ID_PREVISION := get_info(p_numero_compte => p_row.NUMERO_COMPTE
                                                            , p_date => p_row.DATE_PIECE
                                                            ,p_info => 'PREVISION'
                                                            , p_message => l_message);      */
        
    begin 
     if p_row.sens  in ('D','C') then   
               
      
        case p_row.sens
            when 'D' then l_montant:= to_number( p_row.debit);
            when 'C' then l_montant := to_number( p_row.credit);
            else l_montant :=0;
        end case ;
          if l_montant <= 0 or l_montant is null then   
                 l_message:= l_message || ' Montant doit etre supérieur à 0 ';
          end if;      
        p_row.montant := l_montant;
     else
              l_message:= l_message || ' Sens de lecriture non conforme. ';
     end if;
    exception when others then
            l_message:= l_message || ' Montant non numerique';
    end;
        
   
    if l_message is not null then
        p_row.statut_transformation := l_message;
            else
        p_row.statut_transformation := 'OK';
   end if;
                                          
    
 end transformer;
 
 function verif_import_fichier( p_nom_fichier varchar2) return number
 is
 l_nbre_ligne_import number;
 begin
 if p_nom_fichier is not null then
        select count (id_row) into l_nbre_ligne_import from lignes_compta_v 
        where nom_fichier=p_nom_fichier
        and statut_importation ='OK';
        
        return l_nbre_ligne_import;
 else
        return 1;
 end if;
 end verif_import_fichier;    



  procedure supprimer_fichier (p_nom_fichier varchar2)
  is
  
  begin
    if verif_import_fichier(p_nom_fichier) =0 then
            delete from lignes_compta_v where nom_fichier=p_nom_fichier;
    end if;
  end supprimer_fichier ;
 
 
 function inserer_ligne_execution (p_row in out  LIGNES_COMPTA_V%rowtype, p_id_entete number) return varchar2
 is
 l_id_exec number;
 p_exec BUDGET_EXECUTIONS_V%rowtype;
 
 begin
            begin
                    p_exec.id_rubrique := p_row.ID_RUBRIQUE;
                    p_exec.quantite :=1;
                    p_exec.valeur_unitaire := p_row.montant;
                    p_exec.valeur_totale := p_row.montant;
                    p_exec.id_prevision := p_row.id_prevision;
                    p_exec.date_execution := p_row.date_piece;
                    p_exec.id_execution_entete:= p_id_entete;
                    
                    insert into BUDGET_EXECUTIONS_V values p_exec;
                    
                  select max( id_execution) into l_id_exec from BUDGET_EXECUTIONS_V;
                  
            exception when others then
                return sqlerrm;
            end;
            return l_id_exec;
            
 end inserer_ligne_execution;
 
 function inserer_ligne_entete (p_row in out  LIGNES_COMPTA_V%rowtype) return varchar2
 is
 l_id_entete number;
 p_ENT BUDGET_EXECUTION_ENTETE_V%rowtype;
 
 begin
            begin
                    p_ENT.ID_PREVISION_ENTETE := p_row.ID_PREVISION_ENTETE;
                    p_ENT.date_execution := p_row.date_piece;
                   
                    
                    insert into BUDGET_EXECUTION_ENTETE_V values p_ENT;
                    
                  select max( id_execution_entete) into l_id_entete from BUDGET_EXECUTION_ENTETE_V;
            exception when others then
                return   sqlerrm;
            end; 
            return l_id_entete;
            
 end inserer_ligne_entete;
 
 PROCEDURE importation (p_nom_fichier varchar2) 
 is 
 lentete_prevision number;
 laprevision number;
 lentete_execution varchar2(2000):= null;
 lexecution varchar2(2000):= null;
  begin
 
        if p_nom_fichier is not null then
     --   begin
                for enr in (select * from lignes_compta_v where NOM_FICHIER = p_nom_fichier and STATUT_TRANSFORMATION ='OK' and STATUT_IMPORTATION is null) loop
                    begin
                        select sum (ID_EXECUTION_ENTETE)  into  lentete_execution  from BUDGET_EXECUTION_ENTETE where ID_PREVISION_ENTETE=enr.ID_PREVISION_ENTETE;
                             if to_number(lentete_execution)>0 then
                                     lexecution :=   inserer_ligne_execution(enr, to_number(lentete_execution));
                             elsif  lentete_execution is null then
                                    lentete_execution:=    inserer_ligne_entete(enr);
                                     lexecution :=   inserer_ligne_execution(enr, lentete_execution);
                           
                             end if;
                             update lignes_compta_v set ID_EXECUTION_ENTETE= lentete_execution, ID_EXECUTION=lexecution, STATUT_IMPORTATION='OK'
                             where id_row = enr.id_row;
                             
               exception when others then 
                            update lignes_compta_v set ID_EXECUTION_ENTETE= lentete_execution, ID_EXECUTION=lexecution, STATUT_IMPORTATION=lexecution || ' -' || lentete_execution
                                     where id_row = enr.id_row;
                    end;
                end loop;
      
        end if;
 commit;
 end importation ;
 
 
 
 
 
END FICHIER_COMPTA_IMPORT_PKG;
/

