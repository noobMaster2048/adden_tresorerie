create trigger BI_PROFIL_MENU
    before insert
    on PROFIL_MENU
    for each row
begin   
  if :NEW."ID_PROFIL_MENU" is null then 
    select "PROFIL_MENU_SEQ".nextval into :NEW."ID_PROFIL_MENU" from sys.dual; 
  end if; 
end;

/

