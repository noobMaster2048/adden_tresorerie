create PACKAGE BODY GENERER_BUDGET AS

 v_id_rub number;
             v_type_budget varchar2(50);
             v_periode number;
             v_id_prev_entete number;
             v_id_exec_entete number;

  function  import_fichier(p_param number DEFAULT null)  return number AS
             v_return number;
             
  BEGIN
  
  for enr in (select distinct NUMERO_COMPTE,DATE_ECRITURE, MONTANT, STATUT  from test_budget where NUMERO_COMPTE <> 'NUMERO COMPTE' ) loop
    begin
    begin 
    select id_budget_rubrique, type  into v_id_rub,  v_type_budget from budget_rubriques_v where numero_compte = enr.NUMERO_COMPTE;
     exception when others then      
        return 1;
 end;
 begin
     select id_periode INTO v_periode from periodes_v where upper(NATURE) = upper('MOIS') 
     and to_date(enr.DATE_ECRITURE,'YYYY-MM-DD') between START_DATE and END_DATE;

         exception when others then      
        return 2;
 end;
 begin
       select id_prevision_entete into v_id_prev_entete from budget_previsions_entete where id_periode = v_periode;     
           exception when others then      
        return v_periode;
 end;
 begin
       v_id_exec_entete := recherche_entete(v_id_prev_entete);
    exception when others then      
        return 4;
 end;  
 begin
       if v_id_exec_entete = 0 then
                 insert into BUDGET_EXECUTION_ENTETE_v(DATE_EXECUTION, ID_PREVISION_ENTETE, TYPE_EXECUTION, DESIGNATION) 
                 values (to_date(enr.DATE_ECRITURE,'YYYY-MM-DD'), v_id_prev_entete,v_type_budget,'EXECUTION '||v_type_budget); 
                 select  BUDGET_EXECUTION_ENTETE_SEQ.nextval -1 into v_id_exec_entete from dual;
       end if; 
       exception when others then      
        return 5;
 end;    
 
           insert into  BUDGET_EXECUTIONS_V (ID_RUBRIQUE, QUANTITE, VALEUR_UNITAIRE, VALEUR_TOTALE, ID_PREVISION, DATE_EXECUTION, ID_EXECUTION_ENTETE)
           VALUES(v_id_rub, 1, enr.montant, enr.montant, v_id_prev_entete, to_date(enr.DATE_ECRITURE, 'YYYY-MM-DD'), v_id_exec_entete);
                    
      exception
      when others then
       -- v_code := SQLCODE;
        -- v_errm := SUBSTR(SQLERRM, 1 , 64);
        return 99;
        
    end;
    commit;
 --   return 1;
  
  end loop;
       return 1;
  END  import_fichier ;

  function recherche_entete(p_id_prev in number) 
    return number AS
    v_return number;
  BEGIN
    -- TODO : implémentation requise pour function GENERER_BUDGET.recherche_entete
     begin
    select id_execution_entete into v_return  from budget_execution_entete_v where id_prevision_entete = p_id_prev;
   

    exception
        when no_data_found then
        return 0;
    end;
     RETURN v_return;
  END recherche_entete;
  
 
  
 /* function Ligne_fichier (v_row apex_application_temp_files%rowtype) return boolean
  as
  v_return boolean;
  begin
   null;
   v_id_prev_entete := recherche_prevision(v_row.col003,v_row.col006,v_type_budget,v_periode);
   v_id_exec_entete := recherche_entete (v_id_prev_entete);
   if v_id_exec_entete is null then
                 insert into BUDGET_EXECUTION_ENTETE_v(DATE_EXECUTION, ID_PREVISION_ENTETE, TYPE_EXECUTION) values ( v_row.col006, v_id_prev_entete,v_type_budget);   
   end if;              
  end ;*/
  
  procedure creer_ligne_budget (entete BUDGET_PREVISIONS_ENTETE_V%rowtype, p_id_rubrique number) 
  is
  l_row BUDGET_PREVISIONS_SIEGE_V%rowtype;
  begin
  
  for enr in (select * from BUDGET_PREVISIONS_ENTETE_V where ID_PREVISION_ENTETE=entete.ID_PREVISION_ENTETE) loop
          l_row.ID_PREVISION_ENTETE := enr.ID_PREVISION_ENTETE;
          l_row.id_exercice := enr.ID_EXERCICE;
          l_row.ID_SITE :=enr.ID_SITE;
          l_row.ID_RUBRIQUE := p_id_rubrique;
          l_row.STATUT :='Y';
          
          insert into BUDGET_PREVISIONS_SIEGE_V  values l_row;
          
  end loop;          
  end creer_ligne_budget ;
  
  procedure generer_detail_budget (p_id_entete number)
  is
  begin
   for enr in (select * from BUDGET_PREVISIONS_ENTETE_V where ID_PREVISION_ENTETE = p_id_entete) loop        
        for rub in (select * from budget_rubriques_v 
                        where verif_rubrique_site(enr.id_site, ID_BUDGET_RUBRIQUE) =1 ) loop --portee = 'MULTI' or portee=( select type_site from site_v where id_site = enr.id_site )) loop
                 creer_ligne_budget(enr, rub.id_budget_rubrique);
        end loop;               
   end loop;
  
  end generer_detail_budget;
  
procedure generer_detail_budget_bis (p_id_entete number)
  is
  begin
   for enr in (select * from BUDGET_PREVISIONS_ENTETE_V where ID_PREVISION_ENTETE = p_id_entete) loop        
        for rub in (select * from budget_rubriques_v 
                        where verif_rubrique_site(enr.id_site, ID_BUDGET_RUBRIQUE) =1 
                        and verif_rubrique_budget(id_budget_rubrique, p_id_entete) = 0
                        ) loop --portee = 'MULTI' or portee=( select type_site from site_v where id_site = enr.id_site )) loop
                 creer_ligne_budget(enr, rub.id_budget_rubrique);
        end loop;               
   end loop;
  
  end generer_detail_budget_bis;

        function verif_rubrique_site (p_id_site number, p_id_rubrique number) return number
    is
    begin
                for enr in (select * from BUDGET_RUBRIQUES_V where ID_BUDGET_RUBRIQUE = p_id_rubrique ) loop
                        if enr.portee = 'PROD' then
                            if enr.id_site = p_id_site  then --or enr.id_site is null then 
                                return 1;
                            else 
                                return 0;
                            end if;
                       elsif enr.portee = 'MULTI'     then
                            return 1;
                    elsif enr.portee ='ADMIN' then 
                            if p_id_site =1000 then 
                                return 1;
                            else 
                                return 0;
                            end if;
                    else 
                        return 0;                    
                    end if;                         
                end loop;
    end ;
    
    function verif_rubrique_budget (p_id_rubrique number, p_id_prevision_entete number) return number
    is
    begin
    begin
    for enr in (select * from BUDGET_PREVISIONS_SIEGE_V where ID_PREVISION_ENTETE = p_id_prevision_entete and id_rubrique =p_id_rubrique ) loop
        return 1;
    end loop;
    exception when others then
        return 0;
    end;
        return 0;
    end verif_rubrique_budget ;

END GENERER_BUDGET;
/

