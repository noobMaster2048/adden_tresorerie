create trigger BI_STOCK_DEMANDE_ENTREE
    before insert
    on STOCK_DEMANDE_ENTREE
    for each row
begin   
  if :NEW."ID_DM_ENTREE" is null then 
    select "STOCK_DEMANDE_ENTREE_SEQ".nextval into :NEW."ID_DM_ENTREE" from sys.dual; 
  end if; 
end;

/

