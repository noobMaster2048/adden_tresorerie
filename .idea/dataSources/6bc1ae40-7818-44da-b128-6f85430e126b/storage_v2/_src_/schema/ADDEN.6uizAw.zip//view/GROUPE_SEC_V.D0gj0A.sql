create view GROUPE_SEC_V as
select val.valeur libelle, val.code_valeur code 
from valeurs_parametres_v val, parametres_v par
where par.id_parametre = val.id_parametre
and par.libelle='GROUPE_SEC'
/

