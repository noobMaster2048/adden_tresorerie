create trigger BI_RUBRIQUES_ETATS
    before insert
    on RUBRIQUES_ETATS
    for each row
begin   
  if :NEW."ID_RUBRIQUE" is null then 
    select "RUBRIQUES_ETATS_SEQ".nextval into :NEW."ID_RUBRIQUE" from sys.dual; 
  end if; 
end;

/

