create trigger BI_STOCK_DETAIL_RETOUR
    before insert
    on STOCK_DETAIL_RETOUR
    for each row
begin   
  if :NEW."ID_DETAIL_RETOUR" is null then 
    select "STOCK_DETAIL_RETOUR_SEQ".nextval into :NEW."ID_DETAIL_RETOUR" from sys.dual; 
  end if; 
end;
/

