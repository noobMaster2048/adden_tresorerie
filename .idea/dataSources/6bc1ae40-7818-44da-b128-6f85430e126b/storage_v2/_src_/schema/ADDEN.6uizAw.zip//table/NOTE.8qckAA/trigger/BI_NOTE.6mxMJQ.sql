create trigger BI_NOTE
    before insert
    on NOTE
    for each row
begin   
  if :NEW."ID_ELEV" is null then 
    select "NOTE_SEQ".nextval into :NEW."ID_ELEV" from sys.dual; 
  end if; 
end;

/

