create trigger BI_MENSUALITE
    before insert
    on MENSUALITE
    for each row
begin   
  if :NEW."ID_MENS" is null then 
    select "MENSUALITE_SEQ".nextval into :NEW."ID_MENS" from sys.dual; 
  end if; 
end;

/

