create trigger BI_ENSEIGNANT
    before insert
    on ENSEIGNANT
    for each row
begin   
  if :NEW."ID_ENSEIG" is null then 
    select "ENSEIGNANT_SEQ".nextval into :NEW."ID_ENSEIG" from sys.dual; 
  end if; 
end;

/

