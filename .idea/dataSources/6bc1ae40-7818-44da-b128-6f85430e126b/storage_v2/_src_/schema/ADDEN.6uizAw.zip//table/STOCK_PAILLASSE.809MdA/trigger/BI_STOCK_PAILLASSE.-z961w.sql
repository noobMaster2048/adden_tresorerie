create trigger BI_STOCK_PAILLASSE
    before insert
    on STOCK_PAILLASSE
    for each row
begin   
  if :NEW."ID_PAILLASSE" is null then 
    select "STOCK_PAILLASSE_SEQ".nextval into :NEW."ID_PAILLASSE" from sys.dual; 
  end if; 
end;
/

