create PACKAGE BODY       STOCK_DEMANDE_SORTIE_PKG AS

erreur exception;

function creer_entete_demande(p_date_demande date, p_id_dem varchar2, p_designation varchar2, p_id_salle varchar2) return varchar2
is
 p_record stock_demande_sortie_v%rowtype;
 p_id_demande varchar2(50);
begin        
       p_record.ID_DEMANDEUR := p_id_dem;
        p_record.date_demande := p_date_demande;
        p_record.intitule_demande := p_designation;
        p_record.num_ordre := get_num_ordre( 'SORTIE', 3, p_date_demande) ;
        p_record.statut := 'STOCK_S_DRAFT';
        p_record.id_salle :=  p_id_salle ;
  select stock_demande_sortie_seq.nextval into    p_record.ID_DM_SORTIE  from dual;
     p_id_demande := p_record.num_ordre ;
     begin
        insert into STOCK_DEMANDE_SORTIE_V values p_record;
     exception when others then
            return null;
     end;
     return p_id_demande;
end ;


  procedure creer_detail_demande (p_id_produit number
                                                    , p_quantite number
                                                    ,p_stock number
                                                    , p_num_destock varchar2)
  is
 p_record stock_demande_sortie_detail_v%rowtype;
  l_trouve number;
  begin 
  
  if p_quantite <= p_stock then 
          for enr in (select * from ADDEN.stock_demande_sortie_v where num_ordre = p_num_destock) loop
    
            select count(ID_DM_SORTIE) into l_trouve  from stock_demande_sortie_detail_v where ID_PRODUIT = p_id_produit and ID_DM_SORTIE=enr.ID_DM_SORTIE;
            
             if l_trouve = 0 then
                p_record.id_produit := p_id_produit;
                p_record.quantite_demande := to_number(p_quantite);
                p_record.quantite_stock :=   to_number(p_stock );
                p_record.id_dm_sortie :=to_number(enr.id_dm_sortie);
                p_record.NUM_ORDRE :=p_num_destock;
                p_record.statut := 'Y';
                    begin
                        insert into stock_demande_sortie_detail_v values p_record;
                     exception when others then
                         null;
                     end;
            else
            
            begin
                   update stock_demande_sortie_detail_v set quantite_demande = p_quantite where ID_PRODUIT = p_id_produit and ID_DM_SORTIE=enr.ID_DM_SORTIE;
              exception when others then
                         null;
                     end;  
    
    
         
           end if;
    end loop; 
    
    else 
    
          raise_application_error(-20101, 'Quantité demandé supèrieure au stock');
  
  end if;
  
 
  
  
  end;
  

  procedure modifier_detail_demande (p_id_produit number
                                                    , p_quantite number
                                                    ,p_stock number
                                                    , p_num_destock varchar2)
  is
 p_record stock_demande_sortie_detail_v%rowtype;
  l_trouve number;
  begin 
    for enr in (select * from ADDEN.stock_demande_sortie_v where num_ordre = p_num_destock) loop
    
            select count(ID_DM_SORTIE) into l_trouve  from stock_demande_sortie_detail_v where ID_PRODUIT = p_id_produit and ID_DM_SORTIE=enr.ID_DM_SORTIE;
                       
            begin
                   update stock_demande_sortie_detail_v set quantite_acceptee = p_quantite , QUANTITE_STOCK = p_stock
                   where ID_PRODUIT = p_id_produit and ID_DM_SORTIE=enr.ID_DM_SORTIE;
              exception when others then
                         null;
                     end;         
    end loop;  
  end;
  

function get_num_ordre(p_prefixe varchar2,p_taille number,p_date date)  return varchar2
is
l_numbre number;
l_nbre_part varchar2(10);
l_num varchar2(20);
begin

select count(id_dm_sortie) into l_numbre
from stock_demande_sortie_v
where to_char(date_demande,'dd/mm/yyyy') = to_char(p_date,'dd/mm/yyyy');

l_nbre_part := LPAD( to_char(l_numbre+1),  p_taille , '0' );

return p_prefixe || '_' || l_nbre_part || '_' || to_char(p_date, 'ddmmyy');

end;

 function controle_destockage(p_num_ordre varchar2) return varchar2
 as
 l_message varchar2(2000);
 begin
 
 for enr in (select * from stock_demande_sortie_v where num_ordre = p_num_ordre) loop
 
        for prod in (select * from stock_produits_v pro  where pro.id_produit in (select dem.id_produit from stock_demande_sortie_detail_v dem where dem.id_dm_sortie = enr.id_dm_sortie)) loop
        
                null;
        
        end loop;
 
 end loop;
 
 
 return null;
 end;
 
 function destockage_Produit (p_id_produit number, p_num_ordre varchar2) return varchar2
 is 
    l_methode varchar2(20);
    l_test number ;
 begin
 -- l_test := 100/ to_number('4ly');
 
    for prod in (select * from stock_produits_v pro where pro.ID_PRODUIT = p_id_produit) loop
        case prod.METH_DESTOCK
            when 'FIFO' then
                return destockage(p_id_produit,p_num_ordre, 'ASC', prod.METH_DESTOCK) ;
            when 'LIFO' then
                return  destockage(p_id_produit,p_num_ordre, 'DESC', prod.METH_DESTOCK) ;
            when 'PEREMP_DESC' then
                return  destockage(p_id_produit,p_num_ordre, 'DESC', prod.METH_DESTOCK) ;
            when 'PEREMP_ASC' then
                return  destockage(p_id_produit,p_num_ordre, 'ASC', prod.METH_DESTOCK) ;
            else
                return 'Methode de destockage non reconnu dans le système';
        end case;
    end loop;
 --return null;
 end;
 
 function destockage (p_id_produit number, p_num_ordre varchar2, p_ordre varchar2, p_methode varchar2 ) return varchar2
 is
 l_message varchar2(2000);
 l_sql_str varchar2(2000);
 l_rec_lot STOCK_LOTS_V%rowtype;
 l_reste number DEFAULT 1;
 l_qte_sortie number;
 l_qte_lot number;
 l_stock_lot number;
 l_nombre_lots number;
 
 l_QUANTITE_SORTIE number;
 l_STOCK number;
 
 begin 
 l_reste := 100;
 begin
    for dest in (select * from stock_demande_sortie_detail_v det where det.ID_PRODUIT = p_id_produit and det.NUM_ORDRE =p_num_ordre) loop                    
        l_qte_sortie := dest.QUANTITE_ACCEPTEE;  
        
        select count (l.ID_LOT)into l_nombre_lots  from stock_lots_v l where l.ID_PRODUIT = p_id_produit and STATUT is null and  nvl( STOCK , QUANTITE) > 0;
        
        if l_nombre_lots = 0 then l_message := 'Pas de lots disponibles'; end if;
        case p_methode
        when 'FIFO' then
          l_sql_str:= 'select * from stock_lots_v  where ID_PRODUIT = ' ||  p_id_produit ||   ' and STATUT is null and  nvl( STOCK , QUANTITE) > 0 order by DATE_LOT '; 
            l_sql_str := l_sql_str || p_ordre ||' fetch first 1 row only' ;  
        when 'LIFO' then
          l_sql_str:= 'select * from stock_lots_v  where ID_PRODUIT = ' ||  p_id_produit ||   ' and STATUT is null and  nvl( STOCK , QUANTITE) > 0 order by DATE_LOT '; 
            l_sql_str := l_sql_str || p_ordre ||' fetch first 1 row only' ;  
        when 'PEREMP_DESC' then   
          l_sql_str:= 'select * from stock_lots_v  where ID_PRODUIT = ' ||  p_id_produit ||   ' and STATUT is null and  nvl( STOCK , QUANTITE) > 0 order by DATE_PEREMPTION '; 
            l_sql_str := l_sql_str || p_ordre ||' fetch first 1 row only' ;  
        when 'PEREMP_ASC' then
          l_sql_str:= 'select * from stock_lots_v  where ID_PRODUIT = ' ||  p_id_produit ||   ' and STATUT is null and  nvl( STOCK , QUANTITE) > 0 order by DATE_PEREMPTION '; 
            l_sql_str := l_sql_str || p_ordre ||' fetch first 1 row only' ;      
        else
            l_sql_str:= 'select * from stock_lots_v  where ID_PRODUIT = ' ||  p_id_produit ||   ' and STATUT is null and  nvl( STOCK , QUANTITE) > 0 order by DATE_LOT '; 
            l_sql_str := l_sql_str || p_ordre ||' fetch first 1 row only' ;  
        end case;
        
       DBMS_output.put_line (l_sql_str);
        
        
        while (l_reste > 0 and l_nombre_lots > 0 ) loop                
           
            execute immediate l_sql_str into l_rec_lot;     
            
                l_stock_lot := nvl(l_rec_lot.STOCK,l_rec_lot.QUANTITE);
                
                if  l_stock_lot > 0 then
                
                    if l_qte_sortie > l_stock_lot then 
                            l_qte_lot := l_stock_lot;
                    else
                            l_qte_lot := l_qte_sortie;
                    end if;
                    -- l_rec_lot.QUANTITE_SORTIE := l_qte_lot;
                    -- l_rec_lot.STOCK := nvl(l_rec_lot.STOCK,l_rec_lot.QUANTITE)- l_qte_lot;
                    --    l_rec_lot.statut := 'OQP';
                     --   l_rec_lot.NUM_ORDRE := dest.NUM_ORDRE;
                
                  --  update STOCK_LOTS_V set  ROW =  l_rec_lot;
                    update STOCK_LOTS_V set QUANTITE_SORTIE = l_qte_lot, STOCK = nvl(l_rec_lot.STOCK,l_rec_lot.QUANTITE)- l_qte_lot, statut = 'S', NUM_ORDRE = dest.NUM_ORDRE
                    where ID_LOT = l_rec_lot.id_lot;
                    
                    commit;
                    
                    l_reste := l_qte_sortie - l_stock_lot;
                    l_qte_sortie := l_qte_sortie - l_qte_lot;
                    select count (l.ID_LOT)into l_nombre_lots  from stock_lots_v l where l.ID_PRODUIT = p_id_produit and STATUT is null and  nvl( STOCK , QUANTITE) > 0;
        
                end if; 
             
        end loop;
        
         if l_nombre_lots = 0 then l_message := l_message ||  ' Plus de lots disponible s'; end if;
         if l_reste > 0 then l_message := l_message || ' stock insuffisant '; end if;
         
         return l_message;
       
    end loop;
    
  exception when others then
    return substr(SQLERRM, 1,200);
  end;    
 
-- return null;
 
 end ;
 
 function Annuler_destockage (p_id_produit number, p_num_ordre varchar2 ) return varchar2
 is
 begin
 begin
 
    update STOCK_LOTS_V set QUANTITE_SORTIE = null, STOCK = nvl(STOCK,0)+ QUANTITE_SORTIE , statut = null, NUM_ORDRE = null
                    where NUM_ORDRE = p_num_ordre and id_produit = p_id_produit;
                    
                    commit;
 
 exception when others then
    return substr(SQLERRM, 1,200);
  end;   
   return null;
 end;
 
function Annuler_destockage_demande ( p_id_demande number ) return varchar2
 is
 begin
     begin
     
         for enr in (select * from stock_demande_sortie_v where ID_DM_SORTIE= p_id_demande) loop
         
            update STOCK_LOTS_V set QUANTITE_SORTIE = null, STOCK = nvl(STOCK,0)+ QUANTITE_SORTIE , statut = null, NUM_ORDRE = null
                            where NUM_ORDRE = enr.num_ordre ;
                            
                            commit;
         end loop;
     
     exception when others then
        return substr(SQLERRM, 1,200);
     end;   
  
   return null;
 end;
 
  function liberer_lots (p_id_demande number) return varchar2
  is
  begin     
  for enr in (select * from STOCK_DEMANDE_SORTIE_V  where ID_DM_SORTIE= p_id_demande) loop
        begin
  update STOCK_LOTS_V set QUANTITE_SORTIE = null, STOCK = nvl(STOCK,0)+ QUANTITE_SORTIE , statut = null, NUM_ORDRE = null
                    where NUM_ORDRE = enr.num_ordre ;                    
                    commit; 
     exception when others then
        return substr(SQLERRM, 1,200);
  end;    
  end loop;
     return null;  
  end;
  
   function liberer_lots_pour_cloture (p_id_demande number) return varchar2
  is
  begin     
  for enr in (select * from STOCK_DEMANDE_SORTIE_V  where ID_DM_SORTIE= p_id_demande) loop
        begin
  update STOCK_LOTS_V set QUANTITE_SORTIE = null --, STOCK = nvl(STOCK,0)+ QUANTITE_SORTIE 
  , statut = null, NUM_ORDRE = null
                    where NUM_ORDRE = enr.num_ordre ;                    
                    commit; 
     exception when others then
        return substr(SQLERRM, 1,200);
  end;    
  end loop;
     return null;  
  end;
  
function mvt_Sortie_stock (p_id_demande number) return varchar2
is
l_mvt_stock STOCK_MVT_PRODUIT_v%rowtype;
begin

    for dem in (select * from stock_demande_sortie_v where ID_DM_SORTIE = p_id_demande) loop
      for lot in (select * from stock_lots_v where num_ordre = dem.num_ordre) loop
            l_mvt_stock := null;
            l_mvt_stock.DATE_MVT:= sysdate;
            l_mvt_stock.ID_PRODUIT := lot.ID_PRODUIT;
          --  l_mvt_stock.ID_lieu:= bl.ID_LIEU;
            l_mvt_stock.ID_TYPE_MVT := 'S';
            l_mvt_stock.ID_DEMANDE := p_id_demande;
            l_mvt_stock.ID_LOT := lot.ID_LOT;
            l_mvt_stock.qte := lot.QUANTITE_SORTIE;
            l_mvt_stock.designation := dem.INTITULE_DEMANDE;
            l_mvt_stock.id_salle := dem.id_salle;
           -- l_mvt_stock.id_fournisseur := dem.ID_DEMANDEUR;
        begin    
            insert into STOCK_MVT_PRODUIT_v values l_mvt_stock;
            commit;
        exception when others then
             return substr(SQLERRM, 1,200);
        end; 
      end loop;
    end loop;
 return null;  
end;

 function destockage_lott (p_id_lot number, p_qte number, p_num_ordre varchar2) return varchar2
 is
 
 begin
 
         begin 
                 update STOCK_LOTS_V set statut = 'S', stock = nvl(STOCK, QUANTITE) - p_qte, QUANTITE_SORTIE = p_qte, NUM_ORDRE = p_num_ordre
                 where ID_LOT = p_id_lot;
                 commit;
         exception when others then
                     return substr(SQLERRM, 1,200);
         end; 
        
 return null;
 end;
 
 function condition_cloture_sortie(p_id_demande number) return varchar2
 is
 
     l_nombre number;
     l_resultat varchar2(2000);
 
 begin
 
 for enr in (select * from stock_demande_sortie_v dem where dem.id_dm_sortie= p_id_demande) loop
 
 
 
     select count( ID_LOT ) into l_nombre from stock_lots_v lot where lot.num_ordre = enr.num_ordre;
    
         if l_nombre > 0 then 
            return null ;
        else 
         raise_application_error(-20100, 'Pas de sortie de produit enregistré pour cette demande !');
             return  'Pas de sortie de produit enregistré pour cette demande !';
        end if;
 
 end loop;
 

 
    return null;
 
 end;
 
 
procedure init_statut(p_id_demande number)
is
begin

begin

   update STOCK_DEMANDE_SORTIE_DETAIL_V set statut = 'Y' where ID_DM_SORTIE= p_id_demande;
   commit;
   
exception when others then
    null;
end;

end;


function controle_preparation(p_id_demande number) return varchar2
is
l_message varchar2(320);
l_nbre number;


begin


 select count(ID_DM_SORTIE) into l_nbre from stock_demande_sortie_detail_v where ID_DM_SORTIE = p_id_demande;
 if l_nbre =0 then 
    raise_application_error(-20207, 'Vous n''avez pas ajouté de produits pour la demande de sortie de st ock!');
 end if;
/* 
 for enr in (select * from STOCK_DEMANDE_STOCK_DETAIL_V where ID_DM_STOCK =p_id_demande and PRIX_ACHAT is null ) loop
    raise_application_error(-20206, 'Vous n''avez pas saisi tous les prix d''achat !');
 end loop;
 */
 return null;
end ;

  function controle_destockage(p_id_demande number) return varchar2
  is
  begin
  
  for enr in (select * from STOCK_DEMANDE_SORTIE_DETAIL_V where QUANTITE_ACCEPTEE is null ) loop
            raise_application_error(-20204, 'Vous n''avez pas saisi les quantités acceptées pour tous les produits demandés');
  end loop;
  
  
  return null;
  end;

END STOCK_DEMANDE_SORTIE_PKG;
/

