create trigger BI_STOC_PRODUITS
    before insert
    on STOCK_PRODUITS
    for each row
begin   
  if :NEW."ID_PRODUIT" is null then 
    select "STOC_PRODUITS_SEQ".nextval into :NEW."ID_PRODUIT" from sys.dual; 
  end if; 
end;

/

