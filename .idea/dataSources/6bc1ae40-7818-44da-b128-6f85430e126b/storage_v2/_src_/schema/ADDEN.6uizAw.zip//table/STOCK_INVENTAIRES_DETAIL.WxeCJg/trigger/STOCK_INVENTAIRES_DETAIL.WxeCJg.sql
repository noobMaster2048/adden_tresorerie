create trigger STOCK_INVENTAIRES_DETAIL
    before insert or update
    on STOCK_INVENTAIRES_DETAIL
    for each row
begin   
  if inserting and :NEW."ID_DETAIL" is null then 
    select "STOCK_INVENTAIRES_DETAIL_SEQ".nextval into :NEW."ID_DETAIL" from sys.dual; 
  end if;
  if inserting then
        :new.INSERT_USER := v('USER');
        :new.INSERT_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
    if updating then
        :new.UPDATE_USER := v('USER');
        :new.UPDATE_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
        :new.total := :new.STOCK_THEORIQUE - :new.STOCK_REEL;
    end if;
end;
/

