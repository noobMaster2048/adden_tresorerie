create PACKAGE CLIENTS_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
function init_values( 
    v_id_client number default global_pkg.number_default_v
    , v_sigle varchar2 default global_pkg.varchar_default_v
    , v_raison_sociale varchar2 default global_pkg.varchar_default_v
    , v_id_pays number default global_pkg.number_default_v
    , v_ville varchar2 default global_pkg.varchar_default_v
    , v_start_date date default global_pkg.date_default_v
    , v_end_date date default global_pkg.date_default_v
    , v_statut varchar2 default global_pkg.varchar_default_v
    , v_insert_date date default global_pkg.date_default_v
    , v_insert_number number default global_pkg.number_default_v
    , v_update_date date default global_pkg.date_default_v
    , v_update_number number default global_pkg.number_default_v
    ) return clients_v%rowtype;
    
procedure inserter( rec in out nocopy clients%rowtype);
procedure updater ( rec in out nocopy clients%rowtype);
procedure deleter (v_id_client number default global_pkg.number_default_v);

END CLIENTS_PKG;
/

