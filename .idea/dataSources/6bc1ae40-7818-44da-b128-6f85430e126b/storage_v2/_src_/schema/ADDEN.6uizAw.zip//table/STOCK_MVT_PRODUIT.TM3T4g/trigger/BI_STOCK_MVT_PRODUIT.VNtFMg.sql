create trigger BI_STOCK_MVT_PRODUIT
    before insert
    on STOCK_MVT_PRODUIT
    for each row
begin   
  if :NEW."ID_MVT_PRODUIT" is null then 
    select "STOCK_MVT_PRODUIT_SEQ".nextval into :NEW."ID_MVT_PRODUIT" from sys.dual; 
  end if; 
end;

/

