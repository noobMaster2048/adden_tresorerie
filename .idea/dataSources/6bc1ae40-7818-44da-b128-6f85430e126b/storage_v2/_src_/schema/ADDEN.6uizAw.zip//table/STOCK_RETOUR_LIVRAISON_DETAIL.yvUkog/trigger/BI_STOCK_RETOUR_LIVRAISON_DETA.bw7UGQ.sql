create trigger BI_STOCK_RETOUR_LIVRAISON_DETA
    before insert
    on STOCK_RETOUR_LIVRAISON_DETAIL
    for each row
begin   
  if :NEW."ID_DETAIL" is null then 
    select "STOCK_RETOUR_LIVRAISON_DETAIL_SEQ".nextval into :NEW."ID_DETAIL" from sys.dual; 
  end if; 
end;
/

