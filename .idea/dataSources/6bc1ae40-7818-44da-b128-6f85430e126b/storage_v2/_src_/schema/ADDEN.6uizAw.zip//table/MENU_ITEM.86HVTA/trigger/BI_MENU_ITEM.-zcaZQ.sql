create trigger BI_MENU_ITEM
    before insert
    on MENU_ITEM
    for each row
begin   
  if :NEW."ID_MENU" is null then 
    select "MENU_ITEM_SEQ".nextval into :NEW."ID_MENU" from sys.dual; 
  end if; 
end;

/

