create trigger BI_PIECE_COMPTABLES
    before insert
    on PIECE_COMPTABLES
    for each row
begin   
  if :NEW."ID_PIECE" is null then 
    select "PIECE_COMPTABLES_SEQ".nextval into :NEW."ID_PIECE" from sys.dual; 
  end if; 
end;

/

