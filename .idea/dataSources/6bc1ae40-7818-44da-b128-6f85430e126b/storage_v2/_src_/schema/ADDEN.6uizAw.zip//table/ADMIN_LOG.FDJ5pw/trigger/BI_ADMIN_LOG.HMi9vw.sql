create trigger BI_ADMIN_LOG
    before insert
    on ADMIN_LOG
    for each row
begin   
  if :NEW."ID_ADMIN_LOG" is null then 
    select "ADMIN_LOG_SEQ".nextval into :NEW."ID_ADMIN_LOG" from sys.dual; 
  end if; 
end;

/

