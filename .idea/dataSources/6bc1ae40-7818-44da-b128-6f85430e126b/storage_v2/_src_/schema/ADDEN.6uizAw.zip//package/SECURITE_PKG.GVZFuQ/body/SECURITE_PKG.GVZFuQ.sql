create PACKAGE BODY                                  SECURITE_PKG AS

  function get_usergroupe(p_user in varchar2, p_date in date default sysdate) return varchar2  AS
    tmp VARCHAR2(4000):= ':';
  BEGIN
    -- TODO : implémentation requise pour function SECURITE_PKG.get_usergroupe
    for gp in (select * 
               from GROUPEPROFIL_USER 
               where 1=1
               and (DATE_FIN is null or  p_date<=DATE_FIN )
               and USER_NAME = upper(trim(p_user))
               and ACTIF = 'Y'
               )
    loop
      tmp:=tmp||':'||gp.ID_GROUPE_PROFIL;  null;
    end loop;
    tmp:=REPLACE(tmp, '::', ':')  ;
    RETURN tmp||':';
  END get_usergroupe;

  function get_userprofile(p_user in varchar2, p_date in date default sysdate) return varchar2  AS
  tmp VARCHAR2(4000):= ':';
  BEGIN
    -- TODO : implémentation requise pour function SECURITE_PKG.get_userprofile
   for prf in (select p.* 
               from GROUPEPROFIL_USER  g , groupe_profil p
               where 1=1 
               and upper(trim(g.ID_GROUPE_PROFIL)) = upper(trim(p.ID_GROUPE_PROFIL))
               and (p.DATE_FIN is null or  p_date<=p.DATE_FIN )
               and g.USER_NAME = upper(trim(p_user))
               and upper(trim(p.ACTIF)) = 'Y'
               )
    loop
      tmp:=tmp||':'||prf.ID_PROFIL;  null;
    end loop;
    tmp:=REPLACE(tmp, '::', ':')  ;
    RETURN tmp||':'; 
  END get_userprofile;

   function is_usergroupe(p_user in varchar2, p_groupe in varchar2) return boolean as
   v_val number;
   begin
     v_val := INSTR( get_usergroupe(p_user => p_user ) , ':'||p_groupe ) ;
     return v_val> 0 ;  
   end is_usergroupe ;
   
   function is_userprofile(p_user in varchar2, p_profile in varchar2) return boolean as
    v_val number;
   begin
     if SECURITE_PKG.is_usergroupe(p_user => p_user , p_groupe =>'G_ADMIN' ) then
        return true;
     end if;   
     v_val := INSTR( get_userprofile(p_user => p_user ) , ':'||p_profile ) ;
     return v_val> 0 ;   
   end is_userprofile ;
   /*
   function is_usersite(p_user in varchar2, p_site in number) return boolean as
    tmp VARCHAR2(4000):= ':';
   begin
   
    for st in (select *
               from utilisateur_site
               where 1=1
               and USERNAME = p_user
               and ID_SITE = p_site
               )
    loop
      return true ;
    end loop;
     return false ;   
   end is_usersite ;
   */
   function is_usersite(p_user in varchar2, p_site in number) return number as
    tmp VARCHAR2(4000):= ':';
   begin
   
     if SECURITE_PKG.isadmin(p_user => p_user ) then 
      return 2;
     end if; 
   
    for st in (select *
               from utilisateur_site
               where 1=1
               and USERNAME = p_user
               and ID_SITE = p_site
               )
    loop
      return 1 ;
    end loop;
     return 0 ;   
   end is_usersite ;   
   
  function set_password(p_user in varchar2 , p_newpwd in varchar2, p_ancienpwd in varchar2) return varchar2  AS
  tmp VARCHAR2(4000):= ':';
  VAL boolean := false;
  BEGIN
    -- TODO : implémentation requise pour function SECURITE_PKG.set_password
    VAL := APEX_UTIL.IS_LOGIN_PASSWORD_VALID (
        p_username=>p_user,
        p_password=>p_ancienpwd);
        
    if val then     
       APEX_UTIL.CHANGE_CURRENT_USER_PW (p_newpwd);
    else 
       RETURN 'MOT DE PASSE NON VALIDE';
    end if;
    RETURN 'MOT DE PASSE CHANGE';
  END set_password;
  
  function isadmin(p_user in varchar2) return boolean as
    v_reponse varchar2(8);
  begin
  
  return SECURITE_PKG.is_usergroupe(p_user => p_user , p_groupe =>'G_ADMIN' ) ;
 /*
  for p in (
   select upper(trim(is_admin)) ad
   from UTILISATEUR_V 
   where user_name = p_user
   )
   loop
     v_reponse := p.ad;
   end loop;
    if v_reponse='YES' then 
    return true ;
    end if;
  return false;
  */
  end isadmin ;

END SECURITE_PKG;
/

