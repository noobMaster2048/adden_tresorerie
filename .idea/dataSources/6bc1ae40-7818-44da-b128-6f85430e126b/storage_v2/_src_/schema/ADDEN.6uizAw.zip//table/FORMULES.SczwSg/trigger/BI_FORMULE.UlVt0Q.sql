create trigger BI_FORMULE
    before insert or update
    on FORMULES
    for each row
begin   
  
  if inserting and :NEW."ID_FORMULE" is null then 
    select "FORMULE_SEQ".nextval into :NEW."ID_FORMULE" from sys.dual; 
  end if;
  if inserting then
        :new.INSERT_USER := v('USER');
        :new.INSERT_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
    if updating then
        :new.UPDATE_USER := v('USER');
        :new.UPDATE_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
end;

/

