create PACKAGE GLOBAL_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
  /* definition des valeurs par defaut des variables utilisées dans les packages*/
  
  number_default_v number := -9999999999999;
  date_default_v date     := to_date('01/01/9999','dd/mm/yyyy');
  varchar_default_v varchar2(20) := '{[[|~||';
  blob_default_v blob default empty_blob();
  
  function get_year (p_date date) return number;
 function get_week (p_date date) return number;
 
 function Get_Month(p_date date) return number;

END GLOBAL_PKG;
/

