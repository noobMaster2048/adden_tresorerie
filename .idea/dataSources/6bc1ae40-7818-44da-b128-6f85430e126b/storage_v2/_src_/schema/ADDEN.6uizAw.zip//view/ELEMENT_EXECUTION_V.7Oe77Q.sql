create view ELEMENT_EXECUTION_V as
select  'OP' nivel ,pr_ent.id_exercice exo
,pr_ent.id_exercice || rub.nature || pr_ent.id_site|| exe.id_rubrique || exe.ID_EXECUTION  ID_ELEMENT
,pr_ent.id_exercice || rub.nature || pr_ent.id_site || exe.id_rubrique  CODE_ELEMENT
, to_char( exe.ID_EXECUTION ) VALEUR_ELEMENT
--, ex_ent.id_prevision_entete, exe.id_prevision, exe.id_execution_entete
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale,0)) janvier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale,0)) fevrier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale,0)) mars
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 4, exe.valeur_totale,0)) avril
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale,0)) mai
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale,0)) juin
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale,0)) juillet
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale,0)) aout
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale,0)) septembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale,0)) octobre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale,0)) novembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale,0)) decembre
,sum(exe.valeur_totale) total
from BUDGET_PREVISIONS_ENTETE_V pr_ent
        , BUDGET_EXECUTION_ENTETE_V ex_ent
        ,BUDGET_EXECUTIONS_V exe
        , BUDGET_RUBRIQUES_V rub
where 1=1
and pr_ent.ID_PREVISION_ENTETE = ex_ent.ID_PREVISION_ENTETE
and ex_ent.ID_EXECUTION_ENTETE = exe.ID_EXECUTION_ENTETE
and exe.id_rubrique=rub.id_budget_rubrique
group by  'OP' , pr_ent.id_exercice 
,pr_ent.id_exercice || rub.nature || pr_ent.id_site|| exe.id_rubrique || exe.ID_EXECUTION  
,pr_ent.id_exercice || rub.nature || pr_ent.id_site || exe.id_rubrique  
,  to_char( exe.ID_EXECUTION ) 
-- par rubrique
union
select  'RUB' nivel, pr_ent.id_exercice exo
,pr_ent.id_exercice || rub.nature || pr_ent.id_site|| exe.id_rubrique  ID_ELEMENT
,pr_ent.id_exercice || rub.nature || pr_ent.id_site  CODE_ELEMENT
, rub.designation VALEUR_ELEMENT
--, ex_ent.id_prevision_entete, exe.id_prevision, exe.id_execution_entete
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale,0)) janvier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale,0)) fevrier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale,0)) mars
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 4, exe.valeur_totale,0)) avril
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale,0)) mai
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale,0)) juin
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale,0)) juillet
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale,0)) aout
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale,0)) septembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale,0)) octobre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale,0)) novembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale,0)) decembre
,sum(exe.valeur_totale) total
from BUDGET_PREVISIONS_ENTETE_V pr_ent
        , BUDGET_EXECUTION_ENTETE_V ex_ent
        ,BUDGET_EXECUTIONS_V exe
        , BUDGET_RUBRIQUES_V rub
where 1=1
and pr_ent.ID_PREVISION_ENTETE = ex_ent.ID_PREVISION_ENTETE
and ex_ent.ID_EXECUTION_ENTETE = exe.ID_EXECUTION_ENTETE
and exe.id_rubrique=rub.id_budget_rubrique
group by 'RUB',  pr_ent.id_exercice 
,pr_ent.id_exercice || rub.nature || pr_ent.id_site|| exe.id_rubrique 
,pr_ent.id_exercice || rub.nature || pr_ent.id_site  
, rub.designation
-- par site
union
select 'SIT' nivel ,pr_ent.id_exercice exo
,pr_ent.id_exercice || rub.nature || pr_ent.id_site ID_ELEMENT
,pr_ent.id_exercice || rub.nature   CODE_ELEMENT
, sit.designation VALEUR_ELEMENT
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale,0)) janvier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale,0)) fevrier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale,0)) mars
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 4, exe.valeur_totale,0)) avril
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale,0)) mai
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale,0)) juin
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale,0)) juillet
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale,0)) aout
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale,0)) septembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale,0)) octobre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale,0)) novembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale,0)) decembre
,sum(exe.valeur_totale) total
from BUDGET_PREVISIONS_ENTETE_V pr_ent
        , BUDGET_EXECUTION_ENTETE_V ex_ent
        ,BUDGET_EXECUTIONS_V exe
        , BUDGET_RUBRIQUES_V rub,
        site_v sit
where 1=1
and pr_ent.ID_PREVISION_ENTETE = ex_ent.ID_PREVISION_ENTETE
and ex_ent.ID_EXECUTION_ENTETE = exe.ID_EXECUTION_ENTETE
and exe.id_rubrique=rub.id_budget_rubrique
and pr_ent.id_site = sit.id_site
group by 'SIT' , pr_ent.id_exercice
,pr_ent.id_exercice || rub.nature || pr_ent.id_site 
,pr_ent.id_exercice || rub.nature 
, sit.designation
-- par nature
union
select 'NAT' nivel, pr_ent.id_exercice exo
,pr_ent.id_exercice || rub.nature   ID_ELEMENT
,to_char(pr_ent.id_exercice)   CODE_ELEMENT
, decode( rub.nature ,'CH','CHARGES','PRODUITS') VALEUR_ELEMENT
--, ex_ent.id_prevision_entete, exe.id_prevision, exe.id_execution_entete
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale*(-1),0))) janvier
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale*(-1),0))) fevrier
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale*(-1),0))) mars
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 4, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')),4, exe.valeur_totale*(-1),0))) avril
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale*(-1),0))) mai
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale*(-1),0))) juin
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale*(-1),0))) juillet
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale*(-1),0))) aout
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale*(-1),0))) septembre
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale*(-1),0))) octobre
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale*(-1),0))) novembre
,sum( decode( rub.nature,'PR', decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale,0),decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale*(-1),0))) decembre

,sum(decode (rub.nature,'PR',exe.valeur_totale, exe.valeur_totale *(-1))) total
from BUDGET_PREVISIONS_ENTETE_V pr_ent
        , BUDGET_EXECUTION_ENTETE_V ex_ent
        ,BUDGET_EXECUTIONS_V exe
        , BUDGET_RUBRIQUES_V rub
where 1=1
and pr_ent.ID_PREVISION_ENTETE = ex_ent.ID_PREVISION_ENTETE
and ex_ent.ID_EXECUTION_ENTETE = exe.ID_EXECUTION_ENTETE
and exe.id_rubrique=rub.id_budget_rubrique
group by 'NAT', pr_ent.id_exercice 
,pr_ent.id_exercice || rub.nature   
,to_char(pr_ent.id_exercice) 
,decode( rub.nature ,'CH','CHARGES','PRODUITS')
-- par exercice
union
select 'EXE' nivel,  pr_ent.id_exercice exo
,to_char(pr_ent.id_exercice)    ID_ELEMENT
,null   CODE_ELEMENT
, to_char(pr_ent.id_exercice) VALEUR_ELEMENT
--, ex_ent.id_prevision_entete, exe.id_prevision, exe.id_execution_entete
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 1, exe.valeur_totale,0)) janvier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 2, exe.valeur_totale,0)) fevrier
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 3, exe.valeur_totale,0)) mars
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 4, exe.valeur_totale,0)) avril
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 5, exe.valeur_totale,0)) mai
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 6, exe.valeur_totale,0)) juin
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 7, exe.valeur_totale,0)) juillet
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 8, exe.valeur_totale,0)) aout
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 9, exe.valeur_totale,0)) septembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 10, exe.valeur_totale,0)) octobre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 11, exe.valeur_totale,0)) novembre
,sum( decode (to_number(to_char(to_date(exe.date_execution,'DD/MM/YYYY'),'mm')), 12, exe.valeur_totale,0)) decembre
,sum(exe.valeur_totale) total
from BUDGET_PREVISIONS_ENTETE_V pr_ent
        , BUDGET_EXECUTION_ENTETE_V ex_ent
        ,BUDGET_EXECUTIONS_V exe
        , BUDGET_RUBRIQUES_V rub
where 1=1
and pr_ent.ID_PREVISION_ENTETE = ex_ent.ID_PREVISION_ENTETE
and ex_ent.ID_EXECUTION_ENTETE = exe.ID_EXECUTION_ENTETE
and exe.id_rubrique=rub.id_budget_rubrique
group by 'EXE',  pr_ent.id_exercice  
,to_char(pr_ent.id_exercice)    
,null    
, to_char(pr_ent.id_exercice)
/

