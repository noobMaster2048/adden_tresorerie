create trigger BI_STOCK_DEMANDE_SORTIE_DETAIL
    before insert
    on STOCK_DEMANDE_SORTIE_DETAIL
    for each row
begin   
  if :NEW."ID_DM_SORTIE_DETAIL" is null then 
    select "STOCK_DEMANDE_SORTIE_DETAIL_SEQ".nextval into :NEW."ID_DM_SORTIE_DETAIL" from sys.dual; 
  end if; 
end;


/

