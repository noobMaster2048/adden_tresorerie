create trigger BI_STOCK_REBUS
    before insert
    on STOCK_REBUS
    for each row
begin   
  if :NEW."REBUS_ID" is null then 
    select "STOCK_REBUS_SEQ".nextval into :NEW."REBUS_ID" from sys.dual; 
  end if; 
  if inserting then
     :NEW.REFERENCE_REBUS:= 'REB'||'_'||"STOCK_REBUS_SEQ".CURRVAL||'_'||to_char(sysdate,'DDMMYY');
  end if;
end;
/

