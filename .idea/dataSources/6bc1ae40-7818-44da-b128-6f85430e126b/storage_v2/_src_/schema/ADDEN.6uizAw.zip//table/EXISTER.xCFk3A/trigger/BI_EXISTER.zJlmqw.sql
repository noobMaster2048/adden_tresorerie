create trigger BI_EXISTER
    before insert
    on EXISTER
    for each row
begin   
  if :NEW."ID_CLASS" is null then 
    select "EXISTER_SEQ".nextval into :NEW."ID_CLASS" from sys.dual; 
  end if; 
end;

/

