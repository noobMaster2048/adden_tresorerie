create PACKAGE FILES_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

 g_format_ligne        tmpfile_v%rowtype;

 procedure set_format_ligne  (
   p_format_ligne   in  tmpfile_v%rowtype
  ) ;


  function get_format_ligne  return tmpfile_v%rowtype;


  function get_str_ligne_num_ligne return number;

  procedure Chargement_fichier(
      p_nom_fichier      varchar2
     ) ;

END FILES_PKG;
/

