create trigger BI_PARAMETRE
    before insert
    on PARAMETRES
    for each row
begin   
  if :NEW."ID_PARAMETRE" is null then 
    select "PARAMETRE_SEQ".nextval into :NEW."ID_PARAMETRE" from sys.dual; 
  end if; 
end;

/

