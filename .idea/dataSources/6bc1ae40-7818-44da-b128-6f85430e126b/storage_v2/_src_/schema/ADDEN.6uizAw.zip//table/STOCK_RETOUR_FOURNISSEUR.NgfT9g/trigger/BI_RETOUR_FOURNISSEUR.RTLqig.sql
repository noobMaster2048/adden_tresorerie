create trigger BI_RETOUR_FOURNISSEUR
    before insert
    on STOCK_RETOUR_FOURNISSEUR
    for each row
begin   
  if :NEW."ID_RETOUR" is null then 
    select "RETOUR_FOURNISSEUR_SEQ".nextval into :NEW."ID_RETOUR" from sys.dual; 
  end if; 
  if inserting then
     -- :NEW.REF_RETOUR := translate(dbms_random.string('x', 20), dbms_random.string('x',6), trunc(dbms_random.value(100000,999999)));
     :NEW.REF_RETOUR:= 'RET'||'_'||"RETOUR_FOURNISSEUR_SEQ".CURRVAL||'_'||to_char(sysdate,'DDMMYY');
  end if;    
end;
/

