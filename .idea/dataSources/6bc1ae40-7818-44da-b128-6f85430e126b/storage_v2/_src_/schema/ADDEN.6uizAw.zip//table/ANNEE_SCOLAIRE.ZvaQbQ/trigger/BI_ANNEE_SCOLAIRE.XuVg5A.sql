create trigger BI_ANNEE_SCOLAIRE
    before insert
    on ANNEE_SCOLAIRE
    for each row
begin   
  if :NEW."ID_ANNESCO" is null then 
    select "ANNEE_SCOLAIRE_SEQ".nextval into :NEW."ID_ANNESCO" from sys.dual; 
  end if; 
end;

/

