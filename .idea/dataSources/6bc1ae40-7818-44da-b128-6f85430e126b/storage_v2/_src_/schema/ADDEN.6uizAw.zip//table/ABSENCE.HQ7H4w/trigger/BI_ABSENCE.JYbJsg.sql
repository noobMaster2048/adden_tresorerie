create trigger BI_ABSENCE
    before insert
    on ABSENCE
    for each row
begin   
  if :NEW."ID_ABS" is null then 
    select "ABSENCE_SEQ".nextval into :NEW."ID_ABS" from sys.dual; 
  end if; 
end;

/

