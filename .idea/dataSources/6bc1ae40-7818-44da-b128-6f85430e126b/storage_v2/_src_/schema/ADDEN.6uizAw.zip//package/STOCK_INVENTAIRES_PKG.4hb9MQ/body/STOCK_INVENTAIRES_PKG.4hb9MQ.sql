create PACKAGE BODY STOCK_INVENTAIRES_PKG AS


function  creer_inventaire(p_intitutle varchar2, p_date date) return number
is
    l_record STOCK_INVENTAIRES_V%rowtype;
begin
    l_record := null;
    l_record.DATE_INV := p_date;
    l_record.DESIGNATION := p_intitutle;
    l_record.statut := 'STOCK_I_DRAFT';
    
    select "STOCK_INVENTAIRES_SEQ".nextval into l_record.ID_INV from sys.dual;     
    insert into STOCK_INVENTAIRES_V values l_record;  
    return l_record.ID_INV;
    
end;

function creer_detail_Inventaire (p_id_inv number) return number
is
l_det STOCK_INVENTAIRES_DETAIL_V%rowtype;
l_compt number default 0;
l_prix number ;
begin

    delete from STOCK_INVENTAIRES_DETAIL_V where ID_INV = p_id_inv;

    for inv in (select * from STOCK_INVENTAIRES_V where id_inv = p_id_inv) loop
        
    
        
         for lot in (select * from STOCK_LOTS_V where nvl(STOCK, QUANTITE) > 0 ) loop
                 begin
                            select  det.prix_achat into  l_prix 
                            from stock_lots lot, stock_demande_stock_v dem, stock_demande_stock_detail_v det
                            where 1=1 and det.ID_DM_STOCK = dem.ID_DM_STOCK and lot.NUM_BL = dem.num_bon_livraison and lot.ID_PRODUIT = det.ID_PRODUIT      and lot.id_lot = lot.id_lot;
                 exception when others then
                        l_prix := null;
                end;
                    
                l_det := null;
                l_det.id_inv := inv.id_inv;
                l_det.id_lot := lot.id_lot;
                l_det.id_produit := lot.id_produit;
                l_det.STOCK_THEORIQUE := nvl(lot.STOCK, lot.QUANTITE);
              --  l_det.STOCK_REEL := nvl(lot.STOCK, lot.QUANTITE);
                l_det.prix_unitaire := l_prix;
                l_det.total := l_prix*  nvl(lot.STOCK, lot.QUANTITE);
                
                insert into STOCK_INVENTAIRES_DETAIL_V values l_det;
                
                l_compt := l_compt +1;
         end loop;
    
    end loop;

return l_compt;
end ;


procedure modifier_stock_lot(p_id_lot number, ecart number)
is 
begin    
    begin
                    update stock_lots_v set stock = nvl(stock , quantite) - ecart  where id_lot = p_id_lot;    
    EXCEPTION when others then
        null;
    end;
end;

procedure insert_mvt_stock( p_id_lot number, p_id_inv number,p_date_inv date, p_lib_inv varchar2,  p_id_produit number, p_type varchar2, p_quantite number) 
is
l_mvt_stock STOCK_MVT_PRODUIT_V%rowtype;
l_id_lieu number;
 begin
 
 select id_lieu into l_id_lieu  from STOCK_PRODUITS_v where id_produit= p_id_produit;
 
       l_mvt_stock := null;
        l_mvt_stock.DATE_MVT:= p_date_inv;
        l_mvt_stock.ID_PRODUIT := p_id_produit;
        l_mvt_stock.ID_lieu:= l_id_lieu;
        l_mvt_stock.ID_TYPE_MVT := p_type;
        l_mvt_stock.ID_DEMANDE := p_id_inv;
        l_mvt_stock.ID_LOT := p_id_lot;
        l_mvt_stock.qte := p_quantite;
        l_mvt_stock.designation :=p_lib_inv;
 --       l_mvt_stock.id_fournisseur := dem.ID_FOURNISSEUR;
        
        insert into STOCK_MVT_PRODUIT_v values l_mvt_stock;
        
end;

procedure cloture_inventaire (p_id_inv number)
is
l_stock_lot number;
l_qte_mvt number;
l_type_mvt varchar2(2);
begin

for inv in ( select * from stock_inventaires_v where id_inv = p_id_inv ) loop
        for enr in (select * from STOCK_INVENTAIRES_DETAIL_V where ID_INV =  p_id_inv and total is not null ) loop
                   modifier_stock_lot(p_id_lot => enr. ID_LOT
                                                    , ecart => enr.total  );
                   select sum(decode(id_type_mvt,'E',qte,0)) -  sum(decode(id_type_mvt,'S',qte,0)) into l_stock_lot 
                    from stock_mvt_produit_v where id_lot= enr.id_lot ;                        
                    if l_stock_lot is not null then
                               if  l_stock_lot <> enr.STOCK_REEL then 
                                      l_qte_mvt := enr.STOCK_REEL - l_stock_lot ;
                                    if l_qte_mvt> 0 then 
                                        l_type_mvt := 'E';
                                        else
                                           l_type_mvt := 'S';
                                    end if;
                              end if;  
                            
                              insert_mvt_stock( 
                              p_id_lot => enr. ID_LOT
                              ,p_id_inv => p_id_inv
                              ,p_date_inv => inv.date_inv
                              , p_lib_inv => inv.designation
                              ,  p_id_produit => enr.id_produit
                              , p_type =>    l_type_mvt 
                              , p_quantite => abs(l_qte_mvt) ) ;
                    end if;                    
        end loop;
end loop;
null;
end;

END STOCK_INVENTAIRES_PKG;
/

