create PACKAGE BODY GLOBAL_PKG AS

  function get_year (p_date date) return number
  is
  v_return number;
  begin
  
    if p_date is not null then
        v_return := extract( year from p_date);
    end if;
    return v_return;
  end get_year;
  
   function get_week(p_date date) return number
  is
  v_return number;
  begin
  
    if p_date is not null then
        v_return := extract( year from p_date);
        
        select to_number(to_char(to_date(p_date,'DD/MM/YYYY'),'iw')) into v_return from dual;
    end if;
    return v_return;
  end get_week;
  
   function Get_Month(p_date date) return number
   is
   v_return number;
   v_month number;
   v_year number;
  begin
  
    if p_date is not null then
        v_return := extract( year from p_date);        
        select to_number(to_char(to_date(p_date,'DD/MM/YYYY'),'mm')) into v_month from dual;
          -- select to_number(to_char(to_date(p_date,'DD/MM/YYYY'),'yyyy')) into v_year from dual;
    end if;
    
    select id_periode into v_return from periodes_v 
    where id_exercice = v_year
    and mois_number = v_month
    and nature ='MOIS';
    
    return v_return;
   end Get_Month;

END GLOBAL_PKG;
/

