create PACKAGE BODY FILES_PKG AS

 procedure set_format_ligne  (
   p_format_ligne   in  tmpfile_v%rowtype
  ) is
  begin
    g_format_ligne   := p_format_ligne;
  end;

  function get_format_ligne  return tmpfile_v%rowtype is
  begin
    return g_format_ligne;
  end;
  function get_str_ligne_num_ligne return number is
  begin
    return g_format_ligne.numero_ligne;
  end;

-- tranfert dans un blob le fichier updloadé
    function charger_fichier_dans_blob (
      p_nom_fichier   varchar2
    , p_supprimer_fichier varchar2 default 'Y'
    , p_commiter   varchar2 default 'Y'
    ) return blob is
        PRAGMA AUTONOMOUS_TRANSACTION;
       blob_fichier blob;
 
    begin
         select blob_content into blob_fichier  from wwv_flow_file_objects$ where name = p_nom_fichier;

       if p_supprimer_fichier = 'Y' then
 --         delete apex_application_files where name = p_nom_fichier;
 --         delete wwv_flow_file_objects$ where name = p_nom_fichier;
          if p_commiter = 'Y' then
             commit;
          end if;
       end if;
       return blob_fichier;

      
    end charger_fichier_dans_blob;
    
     function detacher_lignes_en_colonnes(
      p_row               varchar2
    , p_separateur  varchar2
    ) return tmpfile_v%rowtype is

      l_format_ligne     tmpfile_v%rowtype;
      l_query varchar2(4000);
      l_current_row       number := 1;
      l_previous_row     number := 1;
      l_pos          number :=  1;

    begin
    
     FILES_PKG.set_format_ligne(l_format_ligne);

      if length(p_row) > 0 then
         loop
            l_current_row := instr(p_row, p_separateur,1, l_pos);
            if l_current_row = 0 then
               l_current_row := length(p_row) + 1;
            end if;

            l_query :=
               'declare '
            || '  l_ligne  tmpfile_v%rowtype;'
            || 'begin'
            || '  l_ligne := FILES_PKG.get_format_ligne;'
            || '  l_ligne.'||'COLUMN'||lpad(l_pos, 2, '0')|| ':= '''|| replace( substr(p_row, l_previous_row, l_current_row - l_previous_row), '''','''''') ||''';'
            || '  FILES_PKG.set_format_ligne(l_ligne);'
            || 'end;';
        --    dbms_output.put_line('l_query - '||l_current_row||'-'||l_pos||' : '||l_query);
            execute immediate l_query;

            l_previous_row := l_current_row + 1;
            if l_previous_row  > length(p_row) then
               exit;
            end if;
            l_pos := l_pos + 1;
         end loop;
      end if;  
      return FILES_PKG.get_format_ligne;
   end detacher_lignes_en_colonnes;

 
    procedure tansforme_blob_en_lignes(
		 p_blob              in blob
   , p_separateur  varchar2
    ) is
       l_sep VARCHAR2(2) := chr(13)||chr(10);
       l_last             INTEGER;
       l_current          INTEGER;
       l_current_line    varchar2(2000);
       l_count            INTEGER;
       l_file      tmpfile_v%rowtype;

   
    begin
     
       ---Identification du separateur de ligne
      if (NVL(dbms_lob.instr(p_blob,utl_raw.cast_to_raw(l_sep),1,1),0)=0) then
        l_sep := chr(10);
      end if;
      l_last  := 1;
      l_count := 1;

      LOOP
        l_current := dbms_lob.instr( p_blob, utl_raw.cast_to_raw(l_sep), l_last, 1 );
        if nvl(l_current,0) = 0 then
           l_current := DBMS_LOB.getlength(p_blob) ;
           if l_last < l_current then
              l_current := l_current + 1;
           else
             exit;
           end if;
        end if;

        l_current_line            := utl_raw.cast_to_varchar2(dbms_lob.substr(p_blob,l_current-l_last,l_last));
        l_current_line            := CONVERT(l_current_line, 'UTF8', 'WE8MSWIN1252');

        l_file              := detacher_lignes_en_colonnes(l_current_line, p_separateur) ;
        l_file.numero_ligne := l_count;
        l_file.CONTENU        := l_current_line;

        if l_count > 1
        then
        
          insert into tmpfile_v values l_file;
          
        end if;

        l_count := l_count + 1;
        l_last := l_current+length(l_sep);
          

      end loop;

      end tansforme_blob_en_lignes;

   procedure Chargement_fichier(
      p_nom_fichier      varchar2
     ) is
      p_blob        blob;
   
    begin
  

      if p_nom_fichier is not null then

         p_blob := charger_fichier_dans_blob(
                    p_nom_fichier   =>   p_nom_fichier -- to_char(sysdate, 'dd/mm/yyyy hh:MI:ss') ||  p_nom_fichier
                  , p_supprimer_fichier => 'Y'
                  , p_commiter   => 'Y' );


         tansforme_blob_en_lignes(
                   p_blob => p_blob
                 , p_separateur => ';'
                  );


      else
           raise_application_error(-20001, 'Le fichier doit etre renseigne');
      end if;

    end Chargement_fichier;

END FILES_PKG;
/

