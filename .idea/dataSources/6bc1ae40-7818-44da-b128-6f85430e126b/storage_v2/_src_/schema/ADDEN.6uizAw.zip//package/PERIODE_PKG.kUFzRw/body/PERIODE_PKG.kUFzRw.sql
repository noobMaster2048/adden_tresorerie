create package BODY                                             PERIODE_PKG as

PROCEDURE genere_periode(p_exercice in varchar2) as

p_debut date := sysdate;
p_fin   date := sysdate;
p_date   date := sysdate;

P_existe number := 0 ;
P_week number := 0 ;

P_ID_EXERCICE   number := 0 ;
P_DESIGNATION   varchar2(50) ;
P_START_DATE    date := sysdate;
P_END_DATE      date := sysdate;
P_STATUT        varchar2(8) ;
P_MOIS_NUMBER   number := 0 ;
P_PERIODE	    number := 0 ;
p_nature        varchar2(8);
begin

for exo in (select * from EXERCICES where EXERCICE = to_number(trim(p_exercice)) )
loop
 P_existe := 1 ;
end loop;

if P_existe=0 then 
    INSERT INTO EXERCICES ( 
         EXERCICE
        ,DESIGNATION
        ,START_DATE
        ,END_DATE
        ,STATUT )
    VALUES (
         to_number(trim(p_exercice) )
        ,'EXERCICE '||trim(p_exercice)
        ,to_date('01.01.'||trim(p_exercice),'dd.mm.yyyy')
        ,to_date('31.12.'||trim(p_exercice),'dd.mm.yyyy')
        ,'DRAFT'
    ) ;   
   -- commit ; 
end if;
------------------------ WEEK
p_debut := to_date('01.01.'||trim(p_exercice),'dd.mm.yyyy') ;
p_fin   := to_date('31.12.'||trim(p_exercice),'dd.mm.yyyy') ;

p_date := p_debut ;

P_existe := 0 ;


WHILE to_number(to_char(p_date,'yyyymmdd'))  <  to_number(to_char(p_fin,'yyyymmdd')) -- >
 LOOP
			
for exo in (select * from periodes    
            where nature='WEEK'
			and PERIODE = TO_NUMBER(TO_CHAR (p_date, 'YYYYIW'))
            AND ID_EXERCICE   = trim(p_exercice)
            )
loop
 P_existe := 1 ;
end loop;

    P_week := ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0) + 0 ;

        if P_existe = 0  then
        
        
        P_ID_EXERCICE    := trim(p_exercice) ;
        P_DESIGNATION    := 'Semaine n° : '||TO_CHAR (p_date, 'IW') ||' de '||trim(p_exercice)  ;
        P_START_DATE     := TRUNC(p_date, 'IW')-1 ; --TRUNC(p_date, 'iw');
        P_END_DATE       := NEXT_DAY(TRUNC(p_date,'IW'),'SAMEDI') ; --TRUNC(p_date, 'iw') + 7 - 1/86400;
        P_STATUT         := 'DRAFT';
        P_MOIS_NUMBER    := TO_NUMBER( to_char(p_date,'mm')  )  ;
        P_PERIODE	     := TO_NUMBER(TO_CHAR (p_date, 'YYYY')||TO_CHAR (p_date, 'IW') ) ;
        p_nature         := 'WEEK' ;


                INSERT INTO  PERIODES	(
                             ID_EXERCICE
                            ,DESIGNATION
                            ,START_DATE
                            ,END_DATE
                            ,STATUT
                            ,MOIS_NUMBER		
                            ,PERIODE	
                            ,NATURE
                            ) values	
                            (

                                 P_ID_EXERCICE   ,
                                 P_DESIGNATION   ,
                                 P_START_DATE    ,
                                 P_END_DATE      ,
                                 P_STATUT        ,
                                 P_MOIS_NUMBER   ,
                                 P_PERIODE	      ,
                                 P_nature
                                
                            ) ;
                  P_existe := 0 ;
                    commit ;
        end if;
			
            P_existe := 0 ;
            p_date := p_date + 1 ;

 END LOOP; 


------------------------ MOIS


p_debut := to_date('01.01.'||trim(p_exercice),'dd.mm.yyyy') ;
p_fin   := to_date('31.12.'||trim(p_exercice),'dd.mm.yyyy') ;

p_date := p_debut ;

P_existe := 0 ;


WHILE to_number(to_char(p_date,'yyyymm'))  <  to_number(to_char(p_fin,'yyyymm')) + 1 -- >
 LOOP
			
        for exo in (select * from periodes    
                    where nature='MOIS'
                    and PERIODE = TO_NUMBER(TO_CHAR (p_date, 'YYYYMM') ) 
                    AND ID_EXERCICE  = trim(p_exercice))
        loop
         P_existe := 1 ;
        end loop;

        if P_existe = 0  then
        
        
        P_ID_EXERCICE    := trim(p_exercice) ;
        P_DESIGNATION    := trim(TO_CHAR (p_date, 'MONTH','nls_date_language=FRENCH')) ||' '||trim(p_exercice)  ;
        P_START_DATE     := trunc(p_date) - (to_number(to_char(p_date,'DD')) - 1)  ; 
        P_END_DATE       := LAST_DAY(p_date)  ; --TRUNC(p_date, 'iw') + 7 - 1/86400;
        P_STATUT         := 'DRAFT';
        P_MOIS_NUMBER    := TO_NUMBER( to_char(p_date,'mm')  )  ;
        P_PERIODE	     := TO_NUMBER(TO_CHAR (p_date, 'YYYYMM') );
        p_nature         := 'MOIS' ;


                INSERT INTO  PERIODES	(
                             ID_EXERCICE
                            ,DESIGNATION
                            ,START_DATE
                            ,END_DATE
                            ,STATUT
                            ,MOIS_NUMBER		
                            ,PERIODE	
                            ,NATURE
                            ) values	
                            (

                                 P_ID_EXERCICE   ,
                                 P_DESIGNATION   ,
                                 P_START_DATE    ,
                                 P_END_DATE      ,
                                 P_STATUT        ,
                                 P_MOIS_NUMBER   ,
                                 P_PERIODE	      ,
                                 P_nature
                                
                            ) ;
                  P_existe := 0 ;
                    commit ;
        end if;
			
            P_existe := 0 ;
          --  p_date := ADD_MONTHS(p_date , to_number(to_char(p_date,'mm')) ) ;
            p_date := ADD_MONTHS(p_date , 1 ) ;

 END LOOP; 


------------------------ ANNEE

p_debut := to_date('01.01.'||trim(p_exercice),'dd.mm.yyyy') ;
p_fin   := to_date('31.12.'||trim(p_exercice),'dd.mm.yyyy') ;

p_date := p_debut ;

P_existe := 0 ;


WHILE P_existe = 0 -- >
 LOOP
			
for exo in (select * from periodes    
            where nature='ANNEE'
			and PERIODE = TO_NUMBER(TO_CHAR (p_date, 'YYYY') ))
loop
 P_existe := 1 ;
end loop;

        if P_existe = 0  then
        
        
        P_ID_EXERCICE    := trim(p_exercice) ;
        P_DESIGNATION    := 'Année : '||trim(p_exercice)  ;
        P_START_DATE     := p_debut  ; --TRUNC(p_date, 'iw');
        P_END_DATE       := p_fin  ; --TRUNC(p_date, 'iw') + 7 - 1/86400;
        P_STATUT         := 'DRAFT';
        P_MOIS_NUMBER    := 12  ;
        P_PERIODE	     := TO_NUMBER(TO_CHAR (p_date, 'YYYY') );
        p_nature         := 'ANNEE' ;


                INSERT INTO  PERIODES	(
                             ID_EXERCICE
                            ,DESIGNATION
                            ,START_DATE
                            ,END_DATE
                            ,STATUT
                            ,MOIS_NUMBER		
                            ,PERIODE	
                            ,NATURE
                            ) values	
                            (

                                 P_ID_EXERCICE   ,
                                 P_DESIGNATION   ,
                                 P_START_DATE    ,
                                 P_END_DATE      ,
                                 P_STATUT        ,
                                 P_MOIS_NUMBER   ,
                                 P_PERIODE	      ,
                                 P_nature
                                
                            ) ;
                  P_existe := 0 ;
                    commit ;
        end if;
			
            P_existe := 1 ;
          --  p_date := ADD_MONTHS(p_date , to_number(to_char(p_date,'mm')) ) ;

 END LOOP; 

  --delete from periodes where periode = trim(p_exercice)||'0100';
 -- commit;
 /*
			select TRUNC(p_date, 'iw')                                    AS iso_week_start_date,
				   TRUNC(p_date, 'iw') + 7 - 1/86400                      AS iso_week_end_date,
					TRUNC (p_date, 'mm')                                  AS month_start_date,
					LAST_DAY (TRUNC (p_date, 'mm')) + 1 - 1/86400         as month_end_date  ,
					 ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0) as numero_semaine ,
					 'Semaine n° : '||ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0)||' de '||to_nmber(trim(p_exercice) )  as libelle_semaine ,
					 extract(year from p_date)                             as  annee ,
					 to_char(p_date,'yyyymm')||ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0)  id
			from dual;
*/

/*
trim(p_exercice) --to_number(trim(p_exercice))
,'Semaine n° : '||TO_CHAR (P_week, 'IW') ||' de '||trim(p_exercice)  --ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0)||' de '||to_number(trim(p_exercice) ) --DESIGNATION
,TRUNC(p_date, 'iw')   --START_DATE
,TRUNC(p_date, 'iw') + 7 - 1/86400    --END_DATE
,'DRAFT' --STATUT
,TO_NUMBER( to_char(p_date,'mm')  ) --MOIS_NUMBER		
--,to_char(p_date,'yyyymm')||ROUND((TRUNC(p_date) - TRUNC(p_date, 'YEAR')) / 7,0) --PERIODE
,TO_NUMBER(TO_CHAR (p_date, 'YYYY')||TO_CHAR (p_date, 'IW') ) --to_char(p_date,'yyyymm')||LPAD(P_week,2,'0') --PERIODE
-- ,(  select to_number(to_char(to_date(p_date,'DD/MM/YYYY'),'iw'))  from dual)
*/


end genere_periode;

 function isrecordable( p_exercice in number , p_statut in varchar2) return boolean as
 
 begin 
 for exo in (select count(*)
             from exercices_v
             where 1=1
             and exercice != p_exercice
             and p_statut in ('EXEC','PRE')
             and statut   in ('EXEC','PRE')
            having count(*) > 0
             
             )
   loop
   
   return false;
   
   end loop;
   
   return true;
 end   isrecordable ;


end;
/

