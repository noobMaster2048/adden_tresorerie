create trigger BI_LIGNES_COMPTA
    before insert or update
    on LIGNES_COMPTA
    for each row
begin   
  if inserting and :NEW."ID_ROW" is null then 
    select "LIGNES_COMPTA_SEQ".nextval into :NEW."ID_ROW" from sys.dual; 
  end if;

end;
/

