create PACKAGE BODY WORKFLOW_PKG AS

procedure change_doc_status
  (
    p_process_id         number
   ,p_etape_id       number
   ,p_statut_current    varchar2
   ,p_statut_next      varchar2
   ,p_wkf_code       varchar2
   ,p_comment        varchar2  default null
   ,p_affilie_id     number      default null
   ,p_affilie_type   varchar2    default null
  )
  is
     l_process_id    number;
 

    l_sql       varchar2(32000);
    l_wkf_rec  WKF_WORKFLOW_V%rowtype;
    
    l_envoi_mail     varchar2(32);
    l_mail_sender    varchar2(64);
    l_smtp_hostname  varchar2(64);
    l_smtp_port      varchar2(64);
    
    l_sql_job        varchar2(4000);
    l_job            number;

  begin
 
      select *
        into l_wkf_rec
        from WKF_WORKFLOW_V
        where wkf_code = p_wkf_code;
      l_sql := 'select 1  from '||l_wkf_rec.WKF_TABLE_NAME ||
        ' where '||l_wkf_rec.WKF_COLOMN_NAME || ' = ' || p_process_id || 
        ' and statut' ||' = ''' || p_statut_current || '''';

        execute immediate l_sql into l_process_id;

      l_sql := 'update '||l_wkf_rec.WKF_TABLE_NAME   ||
        ' set statut  = ''' || p_statut_next || ''''||
        ' where '||l_wkf_rec.WKF_COLOMN_NAME || ' = ' || p_process_id ||
        ' and  statut = ''' || p_statut_current || ''''  
        ;

 --     logvm_GEN_utilities_pkg.debug_trace(l_unit_name, 'SQL update:'|| l_sql);

      execute immediate l_sql;
/*
    l_envoi_mail := logvm_GEN_utilities_pkg.get_parameter_value('GEN_ENVOI_MAIL_ALERTE', sysdate);
    if l_envoi_mail = 'O' then
        l_mail_sender   := logvm_GEN_utilities_pkg.get_parameter_value('GEN_ALERTE_SENDER', sysdate);        
        if l_mail_sender is not null then
        
            LOGVM_gen_flows_api.send_mail_from_etape
            (
                p_process_id     => p_process_id
               ,p_etape_id   => p_etape_id
               ,p_date_action   => sysdate
               ,p_send_from  => l_mail_sender
               ,p_affilie_id => p_affilie_id
               ,p_affilie_type => p_affilie_type
             );   
                 
        end if;        
    end if;
    */
  --  logvm_GEN_utilities_pkg.debug_trace(l_unit_name, 'end');
  end change_doc_status;


procedure WKF_Process
  (
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'BUDGET'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) is
     l_code_statut_to     varchar2(32) := null;
     l_erreur_contole     varchar2(32000);
     l_trouve             number := -1;
  
  begin
  --  logvm_gen_utilities_pkg.debug_trace(l_unit_name, 'start');

    for l_etape_rec in (
        select *
          from   wkf_etapes_v
          where  id_etape = p_etape_id
    ) loop
      if  l_etape_rec.condition is null  or verif_condition_etape(p_process_id, l_etape_rec.condition, p_type_wkf) = 1 then
          l_code_statut_to := l_etape_rec.WKF_CODE_STATUT_NEXT;

          if l_code_statut_to is not null then
            l_trouve := 0;
            change_doc_status(
                p_process_id         => p_process_id
              , p_etape_id       => p_etape_id
               ,p_statut_current    => l_etape_rec.WKF_CODE_STATUT_CURRENT
               ,p_statut_next      => l_code_statut_to
               ,p_wkf_code       => p_type_wkf
               ,p_comment        => p_comment
               ,p_affilie_id     => p_affilie_id
               ,p_affilie_type   => p_affilie_type
              );
              
              case l_etape_rec.wkf_code_action
                when 'ABANDONNER' then
                      delete from budget_previsions_siege_v where id_prevision_entete = p_process_id;
                      delete from budget_previsions_entete_v where id_prevision_entete = p_process_id;
                      commit;
                else
                 null;
         
         end case;
              exit;
           else
               l_trouve := 1;
           end if;
         
       

      else
         l_trouve := 1;
      end if;
    end loop;
    
    

  end WKF_Process;


procedure WKF_Process_STOCK_E
  (
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_E'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) is
     l_code_statut_to     varchar2(32) := null;
     l_erreur_contole     varchar2(32000);
     l_trouve             number := -1;
  
  begin
  --  logvm_gen_utilities_pkg.debug_trace(l_unit_name, 'start');

    for l_etape_rec in (
        select *
          from   wkf_etapes_v
          where  id_etape = p_etape_id
    ) loop
      if  l_etape_rec.condition is null  or verif_condition_etape(p_process_id, l_etape_rec.condition, p_type_wkf) = 1 then
          l_code_statut_to := l_etape_rec.WKF_CODE_STATUT_NEXT;

          if l_code_statut_to is not null then
            l_trouve := 0;
       
              /*
              case l_etape_rec.wkf_code_action
                when 'STOCK_E_ABAN_APP' then
                      delete from stock_demande_entree_detail_v where id_dm_entree = p_process_id;
                      delete from stock_demande_entree_v  where id_dm_entree  = p_process_id;
                      commit;
                when 'STOCK_E_CLO' then
                    stock_demande_entree_pkg.mvt_Entree_stock(p_process_id);
              when 'STOCK_E_VAL_APP'and 'STOCK_E_VAL_PRO' and 'STOCK_E_VAl_LIV' then
              stock_demande_entree_pkg.init_statut(p_process_id);
                else
                 null;
         
            end case;
            */
            
              case 
              when  l_etape_rec.wkf_code_action= 'STOCK_E_ABAN_APP' then
                      delete from stock_demande_entree_detail_v where id_dm_entree = p_process_id;
                      delete from stock_demande_entree_v  where id_dm_entree  = p_process_id;
                      commit;
             when  l_etape_rec.wkf_code_action=  'STOCK_E_CLO' then
                    stock_demande_entree_pkg.mvt_Entree_stock(p_process_id);
              when  l_etape_rec.wkf_code_action in (  'STOCK_E_VAL_APP', 'STOCK_E_VAL_PRO' , 'STOCK_E_VAl_LIV') then
              stock_demande_entree_pkg.init_statut(p_process_id);
              when l_etape_rec.wkf_code_action= 'STOCK_E_SOUM_PRO' then
              l_erreur_contole :=  stock_demande_entree_pkg.controle_proforma(p_process_id);
              when l_etape_rec.wkf_code_action= 'STOCK_E_SOUM_APP' then
                    l_erreur_contole :=  stock_demande_entree_pkg.controle_preparation (p_process_id);
                else
                 null;
         
            end case;            
            
            
            if  l_etape_rec.wkf_code_action<> 'STOCK_E_ABAN_APP' then
                        change_doc_status(
                            p_process_id         => p_process_id
                          , p_etape_id       => p_etape_id
                           ,p_statut_current    => l_etape_rec.WKF_CODE_STATUT_CURRENT
                           ,p_statut_next      => l_code_statut_to
                           ,p_wkf_code       => p_type_wkf
                           ,p_comment        => p_comment
                           ,p_affilie_id     => p_affilie_id
                           ,p_affilie_type   => p_affilie_type
                          );
                          
            end if;   
             -- exit;
           else
               l_trouve := 1;
           end if;
         
       

      else
         l_trouve := 1;
      end if;
    end loop;
    
    

  end WKF_Process_STOCK_E;
  

procedure WKF_Process_STOCK_L
  (
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_L'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) is
     l_code_statut_to     varchar2(32) := null;
     l_erreur_contole     varchar2(32000);
     l_trouve             number := -1;
  
  begin
  --  logvm_gen_utilities_pkg.debug_trace(l_unit_name, 'start');

    for l_etape_rec in (
        select *
          from   wkf_etapes_v
          where  id_etape = p_etape_id
    ) loop
      if  l_etape_rec.condition is null  or verif_condition_etape(p_process_id, l_etape_rec.condition, p_type_wkf) = 1 then
          l_code_statut_to := l_etape_rec.WKF_CODE_STATUT_NEXT;

          if l_code_statut_to is not null then
            l_trouve := 0;
            
         
            
              case 
                  when  l_etape_rec.wkf_code_action= 'STOCK_L_ABANDON' then
                          delete from stock_demande_entree_detail_v where id_dm_entree = p_process_id;
                          delete from stock_demande_STOCK_v  where id_dm_STOCK  = p_process_id;
                          commit;
              when  l_etape_rec.wkf_code_action in ( 'STOCK_L_SOUM','STOCL_L_VAL_LIVR') then
                  l_erreur_contole :=  STOCK_DEMANDE_STOCK_PKG.controle_preparation(p_process_id);
                  when  l_etape_rec.wkf_code_action in ('STOCK_L_SOUM_ENTR','STOCK_L_VAL_ENTR') then 
                    l_erreur_contole :=  STOCK_DEMANDE_STOCK_PKG.controle_entreposage(p_process_id);   
                    
                    when   l_etape_rec.wkf_code_action =  'STOCK_L_CLO' then
                      STOCK_DEMANDE_STOCK_PKG.mvt_Entree_stock(p_process_id);
            else
             null;
         
            end case;            
            if l_etape_rec.wkf_code_action<> 'STOCK_L_ABANDON' then
            change_doc_status(
                p_process_id         => p_process_id
              , p_etape_id       => p_etape_id
               ,p_statut_current    => l_etape_rec.WKF_CODE_STATUT_CURRENT
               ,p_statut_next      => l_code_statut_to
               ,p_wkf_code       => p_type_wkf
               ,p_comment        => p_comment
               ,p_affilie_id     => p_affilie_id
               ,p_affilie_type   => p_affilie_type
              );
           end if; 
             -- exit;
           else
               l_trouve := 1;
           end if;
         
       

      else
         l_trouve := 1;
      end if;
    end loop;
    
    

  end WKF_Process_STOCK_L;
  


procedure WKF_Process_STOCK_S
  (
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_S'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
   
  ) is
     l_code_statut_to     varchar2(32) := null;
     l_erreur_contole     varchar2(32000);
     l_trouve             number := -1;
     l_statut varchar2(3200);
     l_condition  varchar2(2000) := null;
  
  begin
  --  logvm_gen_utilities_pkg.debug_trace(l_unit_name, 'start');

    for l_etape_rec in (
        select *
          from   wkf_etapes_v
          where  id_etape = p_etape_id ) loop
      if  l_etape_rec.condition is null  or verif_condition_etape(p_process_id, l_etape_rec.condition, p_type_wkf) = 1 then
          l_code_statut_to := l_etape_rec.WKF_CODE_STATUT_NEXT;

          if l_code_statut_to is not null then
            l_trouve := 0;
          
              
              case  
              when l_etape_rec.wkf_code_action= 'STOCK_S_ABANDON' then
                      delete from STOCK_DEMANDE_SORTIE_DETAIL_V where ID_DM_SORTIE = p_process_id;
                      delete from STOCK_DEMANDE_SORTIE_V  where ID_DM_SORTIE  = p_process_id;
                      commit;
                when  l_etape_rec.wkf_code_action= 'STOCK_S_CLOTURE' then 
                    l_condition := STOCK_DEMANDE_SORTIE_PKG.condition_cloture_sortie(p_process_id);
                      if l_condition is null then  
                          l_statut:=  STOCK_DEMANDE_SORTIE_PKG.mvt_Sortie_stock(p_process_id);
                          if l_statut is null then
                             l_statut :=   STOCK_DEMANDE_SORTIE_PKG.liberer_lots_pour_cloture(p_process_id);
                          end if;
                      end if;
                  
                when l_etape_rec.wkf_code_action= 'STOCK_S_INVAL_DEST'  then                 
                  l_statut:=  STOCK_DEMANDE_SORTIE_PKG.Annuler_destockage_demande (p_process_id);
                  
                when l_etape_rec.wkf_code_action in ('STOCK_S_VAL_DEM') then 
                  STOCK_DEMANDE_SORTIE_PKG.init_statut(p_process_id);
                   l_erreur_contole := STOCK_DEMANDE_SORTIE_PKG.controle_preparation(p_process_id);
                 when l_etape_rec.wkf_code_action in ( 'STOCK_S_VAL_DEST' ) then 
                  STOCK_DEMANDE_SORTIE_PKG.init_statut(p_process_id);
                  l_erreur_contole := STOCK_DEMANDE_SORTIE_PKG.controle_destockage(p_process_id);
              when  l_etape_rec.wkf_code_action in ( 'STOCK_S_SOUM_DEM' ) then
              l_erreur_contole := STOCK_DEMANDE_SORTIE_PKG.controle_preparation(p_process_id);              
              when l_etape_rec.wkf_code_action in ( 'STOCK_S_SOUM_DEST' ) then
                       l_erreur_contole := STOCK_DEMANDE_SORTIE_PKG.controle_destockage(p_process_id);
                  
                else
                
                 null;
         
             end case;
            
      --        if l_condition is  null then  
        if  l_etape_rec.wkf_code_action<> 'STOCK_S_ABANDON' then
              change_doc_status(
                p_process_id         => p_process_id
              , p_etape_id       => p_etape_id
               ,p_statut_current    => l_etape_rec.WKF_CODE_STATUT_CURRENT
               ,p_statut_next      => l_code_statut_to
               ,p_wkf_code       => p_type_wkf
               ,p_comment        => p_comment
               ,p_affilie_id     => p_affilie_id
               ,p_affilie_type   => p_affilie_type
              );
        end if;
   --         end if;
            
              exit;
           else
               l_trouve := 1;
           end if;
         
       

      else
         l_trouve := 1;
      end if;
      
      
    end loop;
    
    

  end WKF_Process_STOCK_S;
  


procedure WKF_Process_STOCK_I
  (
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_I'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) is
     l_code_statut_to     varchar2(32) := null;
     l_erreur_contole     varchar2(320);
     l_trouve             number := -1;
  
  begin
  --  logvm_gen_utilities_pkg.debug_trace(l_unit_name, 'start');

    for l_etape_rec in (
        select *
          from   wkf_etapes_v
          where  id_etape = p_etape_id
    ) loop
      if  l_etape_rec.condition is null  or verif_condition_etape(p_process_id, l_etape_rec.condition, p_type_wkf) = 1 then
          l_code_statut_to := l_etape_rec.WKF_CODE_STATUT_NEXT;

          if l_code_statut_to is not null then
            l_trouve := 0;
               
              case 
                  when  l_etape_rec.wkf_code_action= 'STOCK_I_ABAN' then
                   delete from STOCK_INVENTAIRES_DETAIL_V  where ID_INV  = p_process_id;
                          delete from STOCK_INVENTAIRES_V   where ID_INV = p_process_id;                         
                        --  commit;
                 when  l_etape_rec.wkf_code_action= 'STOCK_I_SOUM' then
                          l_erreur_contole :=  STOCK_INVENTAIRES_PKG. creer_detail_Inventaire(p_process_id);
                when  l_etape_rec.wkf_code_action= 'STOCK_I_CLO' then
                        STOCK_INVENTAIRES_PKG.cloture_inventaire (p_process_id);
                      null;
                    else
                     null;         
            end case;            
           if   l_etape_rec.wkf_code_action<>  'STOCK_I_ABAN'  then
            change_doc_status(
                p_process_id         => p_process_id
              , p_etape_id       => p_etape_id
               ,p_statut_current    => l_etape_rec.WKF_CODE_STATUT_CURRENT
               ,p_statut_next      => l_code_statut_to
               ,p_wkf_code       => p_type_wkf
               ,p_comment        => p_comment
               ,p_affilie_id     => p_affilie_id
               ,p_affilie_type   => p_affilie_type
              );
         end if;   
          --    exit;
           else
               l_trouve := 1;
           end if;
         
       

      else
         l_trouve := 1;
      end if;
    end loop;
    
    

  end WKF_Process_STOCK_I;
  

  
function   verif_condition_etape
  (
    p_process_id     number
   ,p_etape_cond varchar2
  , p_type_wkf       varchar2   default null
  )
  return number
  is
    l_retour number;
    l_sql    varchar2(1000);

    l_tdoc_rec  WKF_WORKFLOW_V%rowtype;

  
  begin
  
    if p_etape_cond is not null then

      select *
        into l_tdoc_rec
        from WKF_WORKFLOW_V
        where WKF_CODE = p_type_wkf;

      l_sql := 'select 1 from '||l_tdoc_rec.WKF_TABLE_NAME ||
        ' where '||l_tdoc_rec.WKF_COLOMN_NAME || ' = ' || p_process_id;
      --  ||' and ('||nvl(p_etape_cond, '1=1')||')';

/*
      l_sql := 'select 1 from ppyrt_cot_declarations_tv where declaration_id = '
             ||nvl(p_process_id, -1)||' and ('||nvl(p_etape_cond, '1=1')||')';
*/
   

      execute immediate l_sql into l_retour;
    else
      l_retour := 1;
    end if;

    return nvl(l_retour, 0);
  exception
    when others then
    null;
      return 0;
  end verif_condition_etape;
  
    function verif_action (p_username varchar2, p_id_etape number, P_WKF_CODE VARCHAR2) return number
    is
       l_val number;
    begin
 
    for enr in (select * from wkf_utilisateur_profil_v where username = p_username and statut ='Y' AND WKF_CODE = P_WKF_CODE) loop    
        for statu in (select * from wkf_etapes_v where id_etape = p_id_etape) loop        
        select count (CODE_PROFIL) into l_val from WKF_STATUS_PROFIL_V 
        where CODE_PROFIL = enr.code_profil  and CODE_STATUT = statu.WKF_CODE_STATUT_CURRENT        ;
        
        if l_val > 0 then 
        return 1;
        else
       null;
        end if;
      /* 
        case statu.WKF_CODE_STATUT_CURRENT        
            when 'DRAFT' then 
                    if enr.code_profil = 'BUDGET_RESP_SITE' then return 1; end if;
             when 'ACHAT' then 
                    if enr.code_profil = 'BUDGET_RESP_ACHA' then return 1; end if;
             when 'RESTAU' then 
                    if enr.code_profil = 'BUDGET_DIR_RESTA' then return 1; end if;
             when 'COMPTA' then 
                    if enr.code_profil = 'BUDGET_COMPTA' then return 1; end if;
             when 'DAAF' then 
                    if enr.code_profil = 'BUDGET_DAAF' then return 1; end if;
             when 'DG' then 
                    if enr.code_profil = 'BUDGET_DIR_G' then return 1; end if;
                    
              when 'STOCK_E_DRAFT' then 
                    if enr.code_profil = 'STOCK_E_ASIST_LABO' then return 1; end if;
             when 'STOCK_E_ATT_VAL' then 
                    if enr.code_profil = 'STOCK_E_RESP_LABO' then return 1; end if;
             when 'STOCK_E_ATT_PROF' then 
                    if enr.code_profil = 'STOCK_E_ASS_STOCK' then return 1; end if;    
              when 'STOCK_E_VAL_PRO' then 
                    if enr.code_profil = 'STOCK_E_RESP_STOCK' then return 1; end if; 
              when 'STOCK_E_ATT_CLO' then 
                    if enr.code_profil = 'STOCK_E_DG' then return 1; end if;        
                    
                    

                    
                    
                    
                    
             else return 0; 
        
        end case;
        */
        end loop;
        
    end loop;
    return 0;
    
    end verif_action ;
  
    function verif_action_bis(p_username varchar2, p_id_entete number) return number
    is
    begin 
            for enr in (select act.affichage
                        , act.designation
                        , etap.id_etape,
                        'javascript:apex.submit(''_WKF_'||etap.id_etape||''');' WKF_etape                        
                        from 
                        wkf_actions_v act
                        , wkf_etapes_v etap
                        , budget_previsions_entete_v bud
                        
                        where act.wkf_code_action = etap.wkf_code_action
                        and ((etap.wkf_code_statut_current = bud.statut) or  ((bud.statut is null)  and etap.wkf_code_statut_current ='DRAFT'))
                        and bud.ID_PREVISION_ENTETE = p_id_entete
                        and etap.wkf_code='BUDGET'
                        and verif_action(p_username,etap.id_etape, ACT.WKF_CODE) =1 ) loop
                        
                        return 1;
            
                       end loop;
                       
                       return 0;
    end verif_action_bis ;


  function verif_init_workflow (p_user varchar2, p_profil varchar2, p_workflow varchar2) return number
  is
  l_count number;
  begin
  
    select count (USERNAME) into l_count from wkf_utilisateur_profil_v 
    where USERNAME = p_user
    and CODE_PROFIL = p_profil
    and WKF_CODE = p_workflow
    and statut ='Y';
    
  return l_count;
  
  return null;
  end;
 


/*
procedure envoi_mail
  (
    p_process_id         number
   ,p_etape_id       number
   ,p_date_action       date
   ,p_send_from      varchar2
   ,p_affilie_id     number      default null
   ,p_affilie_type   varchar2    default null
  )
  is
    pragma autonomous_transaction;
    l_unit_name       varchar2(128) := g_package_name || '.send_mail_from_etape';
    l_list_mail_resp  varchar2(4000); 
    l_list_mail       varchar2(4000) := null;
    l_req_sql         varchar2(4000);
    l_titre_sql       varchar2(4000);
    l_msg_text        varchar2(4000);
    l_titre_text      varchar2(4000);
  begin
  --  logvm_GEN_utilities_pkg.debug_trace(l_unit_name, 'start');
    -- Mail a partir des alertes
    for r in  (select ae.*, doc.nom_table_select, doc.nom_colonne_id
               from ppyrt_gen_alertes_v ae, WKF_WORKFLOW_V doc, wkf_etapes_v etap
               where 1=1
                 and ae.etape_id        = p_etape_id
                 and ae.etape_id        = etap.id_etape
                 and etap.type_document = doc.code_type_doc
               )
    loop    
        logvm_GEN_utilities_pkg.debug_trace(l_unit_name,'p_process_id ='||p_process_id );
        l_msg_text := null;
        
        l_list_mail_resp := LOGVM_gen_flows_api.get_list_mail_resp(p_resp_id => r.resp_id,p_date_action  => p_date_action);
        l_list_mail := l_list_mail || l_list_mail_resp;
        if r.liste_destinataires is not null 
        then
            l_list_mail := l_list_mail || ':'|| r.liste_destinataires;
        end if;
        l_list_mail := ltrim(l_list_mail,':'); 
              
        dbms_output.put_line (l_list_mail);
         
        l_req_sql := 'select ' || r.msg_text || ' message from '|| r.nom_table_select 
                    || ' where '||r.nom_colonne_id || '=' || p_process_id;
                    
        l_titre_sql := 'select ' || r.titre_msg || ' titre from '|| r.nom_table_select 
                    || ' where '||r.nom_colonne_id || '=' || p_process_id;
    
        logvm_GEN_utilities_pkg.debug_trace(l_unit_name,l_req_sql);
    
        execute immediate l_req_sql into l_msg_text;
        execute immediate l_titre_sql into l_titre_text;
        
        logvm_GEN_utilities_pkg.debug_trace(l_unit_name,l_msg_text);
        
        LOGVM_gen_flows_api.send_mail_to_list
         (
             p_list_mail => l_list_mail
            ,p_send_from => p_send_from
            ,p_subject   => l_titre_text
            ,p_text      => l_msg_text
          ); 
    end loop;  
    
    -- mail a partir des messages de l'etape pour adherent ou participant
    l_list_mail := LOGVM_gen_flows_api.get_list_mail_affilie(p_affilie_id,p_affilie_type);
    for r in (select etap.*,doc.nom_table_select, doc.nom_colonne_id 
                from wkf_etapes_v etap,WKF_WORKFLOW_V doc
                 where 1=1
                    and id_etape = p_etape_id 
                    and etap.type_document = doc.code_type_doc
                    and mail_etape is not null
             )
    loop         
        dbms_output.put_line ('l_list_mail adh: '||l_list_mail);
        l_req_sql := 'select ''' || substr(r.mail_etape,instr(r.mail_etape,'#')+1) || ' message from '|| r.nom_table_select 
                    || ' where '||r.nom_colonne_id || '=' || p_process_id;
                    
        l_titre_sql := 'select ' || substr(r.mail_etape,1,instr(r.mail_etape,'#')-1) || ''' titre from '|| r.nom_table_select 
                    || ' where '||r.nom_colonne_id || '=' || p_process_id;
                    
        logvm_GEN_utilities_pkg.debug_trace(l_unit_name,l_req_sql);
    
        execute immediate l_req_sql into l_msg_text;
        execute immediate l_titre_sql into l_titre_text;
        
        logvm_GEN_utilities_pkg.debug_trace(l_unit_name,l_msg_text);
        
        LOGVM_gen_flows_api.send_mail_to_list
        (
            p_list_mail => l_list_mail
           ,p_send_from => p_send_from
           ,p_subject   => l_titre_text 
           ,p_text      => l_msg_text
        );
    end loop;
   -- apex_mail.push_queue; 
    --apex_040200.wwv_flow_mail.push_queue_immediate; 
     apex_050100.wwv_flow_mail.push_queue_immediate; 
    logvm_GEN_utilities_pkg.debug_trace(l_unit_name, 'end');
  end envoi_mail;
*/



END WORKFLOW_PKG;
/

