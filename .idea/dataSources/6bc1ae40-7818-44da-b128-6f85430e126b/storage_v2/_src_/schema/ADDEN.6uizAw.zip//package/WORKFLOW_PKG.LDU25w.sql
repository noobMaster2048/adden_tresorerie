create PACKAGE WORKFLOW_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

TYPE wkf_action_rec IS RECORD(  
     affichage        varchar2(50) 
   , designation        varchar2(50)
   , etape_id     number
   , wkf_etape         varchar2(50)
--   , ordre_etape        number
   ) ;
 TYPE wkf_action_tab IS TABLE OF wkf_action_rec;
 
  procedure WKF_Process
  (  
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'BUDGET'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) ;
 
 procedure WKF_Process_STOCK_E
  (  
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_E'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) ;
  
   procedure WKF_Process_STOCK_L
  (  
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_L'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) ;
  
   procedure WKF_Process_STOCK_S
  (  
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_S'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) ;
  
  
   procedure WKF_Process_STOCK_I
  (  
     p_process_id         number
   , p_etape_id       number
   , p_type_wkf       varchar2   default 'STOCK_I'
   , p_comment        varchar2   default null
   , p_affilie_id     number      default null
   , p_affilie_type   varchar2    default null
  ) ;
  
  function verif_condition_etape
  (
    p_process_id     number
   ,p_etape_cond varchar2
  , p_type_wkf       varchar2   default null
  )
  return number;
  
  function verif_init_workflow (p_user varchar2, p_profil varchar2, p_workflow varchar2) return number;
 
 /*
 procedure envoi_mail
  (
    p_doc_id         number
   ,p_etape_id       number
   ,p_eff_date       date
   ,p_send_from      varchar2
   ,p_affilie_id     number      default null
   ,p_affilie_type   varchar2    default null
  );*/
  
  function verif_action (p_username varchar2, p_id_etape number, P_WKF_CODE VARCHAR2) return number;
  function verif_action_bis(p_username varchar2, p_id_entete number) return number;
END WORKFLOW_PKG;
/

