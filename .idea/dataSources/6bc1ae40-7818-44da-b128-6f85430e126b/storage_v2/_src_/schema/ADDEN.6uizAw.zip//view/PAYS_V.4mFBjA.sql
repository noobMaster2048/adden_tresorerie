create view PAYS_V as
select PAYS.ID_PAYS as ID_PAYS,
    PAYS.NOM as NOM 
 from PAYS PAYS
/

