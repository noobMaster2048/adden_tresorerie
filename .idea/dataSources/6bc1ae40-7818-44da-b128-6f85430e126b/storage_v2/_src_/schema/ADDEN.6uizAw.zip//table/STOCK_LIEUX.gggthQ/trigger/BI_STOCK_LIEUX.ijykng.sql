create trigger BI_STOCK_LIEUX
    before insert
    on STOCK_LIEUX
    for each row
begin   
  if :NEW."ID_LIEU" is null then 
    select "STOCK_LIEUX_SEQ".nextval into :NEW."ID_LIEU" from sys.dual; 
  end if; 
end;

/

