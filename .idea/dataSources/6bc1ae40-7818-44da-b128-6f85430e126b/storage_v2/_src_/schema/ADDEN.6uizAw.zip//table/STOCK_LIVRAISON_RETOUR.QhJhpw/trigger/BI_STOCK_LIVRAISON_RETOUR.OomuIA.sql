create trigger BI_STOCK_LIVRAISON_RETOUR
    before insert
    on STOCK_LIVRAISON_RETOUR
    for each row
begin   
  if :NEW."ID_RETOUR_LIVR" is null then 
    select "STOCK_LIVRAISON_RETOUR_SEQ".nextval into :NEW."ID_RETOUR_LIVR" from sys.dual; 
  end if;
  if inserting then
     :NEW.REFERENCE:= 'RET'||'_'||"STOCK_LIVRAISON_RETOUR_SEQ".CURRVAL||'_'||to_char(sysdate,'DDMMYY');
  end if;
end;
/

