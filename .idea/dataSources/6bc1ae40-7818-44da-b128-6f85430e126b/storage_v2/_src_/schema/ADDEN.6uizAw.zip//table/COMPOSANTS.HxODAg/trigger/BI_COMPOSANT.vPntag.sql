create trigger BI_COMPOSANT
    before insert
    on COMPOSANTS
    for each row
begin   
  if :NEW."ID_COMPOSANT" is null then 
    select "COMPOSANT_SEQ".nextval into :NEW."ID_COMPOSANT" from sys.dual; 
  end if; 
end;

/

