create trigger BI_VALEURS_PARAMETRE
    before insert
    on VALEURS_PARAMETRES
    for each row
begin   
  if :NEW."ID_VALEUR" is null then 
    select "VALEURS_PARAMETRE_SEQ".nextval into :NEW."ID_VALEUR" from sys.dual; 
  end if; 
end;

/

