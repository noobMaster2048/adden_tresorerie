create package GENERER_BUDGET as
    
function import_fichier(p_param number DEFAULT null) return number;
                                  
function recherche_entete(p_id_prev in number)  return number;
   
    procedure generer_detail_budget (p_id_entete number);
     procedure generer_detail_budget_bis (p_id_entete number);
    
    function verif_rubrique_site (p_id_site number, p_id_rubrique number) return number;
    
    function verif_rubrique_budget (p_id_rubrique number, p_id_prevision_entete number) return number;
--function creer_entete_execution(p_id_prev_entete in number)    RETURN number;

end;
/

