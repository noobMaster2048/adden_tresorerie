create trigger BI_STOCK_DEMANDE_SORTIE
    before insert
    on STOCK_DEMANDE_SORTIE
    for each row
begin   
  if :NEW."ID_DM_SORTIE" is null then 
    select "STOCK_DEMANDE_SORTIE_SEQ".nextval into :NEW."ID_DM_SORTIE" from sys.dual; 
  end if; 
end;

/

