create trigger BI_STOCK_MARQUES
    before insert
    on STOCK_MARQUES
    for each row
begin   
  if :NEW."ID_MARQUE" is null then 
    select "STOCK_MARQUES_SEQ".nextval into :NEW."ID_MARQUE" from sys.dual; 
  end if; 
end;

/

