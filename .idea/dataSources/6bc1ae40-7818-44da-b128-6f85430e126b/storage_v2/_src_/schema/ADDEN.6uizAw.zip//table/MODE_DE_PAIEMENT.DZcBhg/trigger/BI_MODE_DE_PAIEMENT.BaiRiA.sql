create trigger BI_MODE_DE_PAIEMENT
    before insert
    on MODE_DE_PAIEMENT
    for each row
begin   
  if :NEW."ID_MOD_PAIE" is null then 
    select "MODE_DE_PAIEMENT_SEQ".nextval into :NEW."ID_MOD_PAIE" from sys.dual; 
  end if; 
end;

/

