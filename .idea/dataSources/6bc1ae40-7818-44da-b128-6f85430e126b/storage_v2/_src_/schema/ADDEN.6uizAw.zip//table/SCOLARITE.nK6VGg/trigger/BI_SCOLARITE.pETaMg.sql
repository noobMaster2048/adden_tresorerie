create trigger BI_SCOLARITE
    before insert
    on SCOLARITE
    for each row
begin   
  if :NEW."ID_MENS" is null then 
    select "SCOLARITE_SEQ".nextval into :NEW."ID_MENS" from sys.dual; 
  end if; 
end;

/

