create trigger BI_STOCK_EMBALLAGE
    before insert
    on STOCK_EMBALLAGE
    for each row
begin   
  if :NEW."ID_EMBALLAGE" is null then 
    select "STOCK_EMBALLAGE_SEQ".nextval into :NEW."ID_EMBALLAGE" from sys.dual; 
  end if; 
end;

/

