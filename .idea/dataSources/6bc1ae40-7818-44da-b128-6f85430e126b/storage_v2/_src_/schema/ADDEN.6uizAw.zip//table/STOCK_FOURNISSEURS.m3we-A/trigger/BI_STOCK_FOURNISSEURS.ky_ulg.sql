create trigger BI_STOCK_FOURNISSEURS
    before insert
    on STOCK_FOURNISSEURS
    for each row
begin   
  if :NEW."ID_FOURNISSEUR" is null then 
    select "STOCK_FOURNISSEURS_SEQ".nextval into :NEW."ID_FOURNISSEUR" from sys.dual; 
  end if; 
end;

/

