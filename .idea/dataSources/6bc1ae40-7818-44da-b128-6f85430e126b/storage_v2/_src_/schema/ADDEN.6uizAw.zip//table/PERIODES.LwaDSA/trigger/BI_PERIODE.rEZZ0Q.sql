create trigger BI_PERIODE
    before insert or update
    on PERIODES
    for each row
begin   

  if inserting and :NEW."ID_PERIODE" is null then 
    select "PERIODE_SEQ".nextval into :NEW."ID_PERIODE" from sys.dual; 
  end if;
  if inserting then
        :new.INSERT_USER := v('USER');
        :new.INSERT_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
    if updating then
        :new.UPDATE_USER := v('USER');
        :new.UPDATE_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
  
end;

/

