create trigger BI_JOURNAUX_COMPTABLES
    before insert or update
    on JOURNAUX_COMPTABLES
    for each row
begin   
  if inserting and :NEW."CODE_JOURNAL" is null then 
    select "JOURNAUX_COMPTABLES_SEQ".nextval into :NEW."CODE_JOURNAL" from sys.dual; 
  end if;
  if inserting then
        :new.INSERT_USER := v('USER');
        :new.INSERT_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
    if updating then
        :new.UPDATE_USER := v('USER');
        :new.UPDATE_DATE  :=to_date(to_char(sysdate,'DD/MM/YY HH24:MI'),'DD/MM/YY HH24:MI');
    end if;
end;

/

