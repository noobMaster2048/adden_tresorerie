create PACKAGE PARAMETRE_PKG AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
  
/**
 Cette fonction ramene la valeur du paramètre à une date donnée
     
     @param p_code in varchar2 code chaine du parametre
     @param p_date in date default sysdate date de reference
     @return  valeur du parametre
     

**/
  function get_paramvalue_by_date(p_code in varchar2, p_date in date default sysdate) return varchar2;
  
  
/**
 
 Cette fonction permet de tester si les date de validités d'un parametre se chauvauchent 
    @param p_code in varchar2 code chaine du parametre 
    @param p_date in date default sysdate 
    @return 
 
**/
  function test_chevauche(p_code in varchar2, p_date in date default sysdate)return boolean ;
 /**
  
      
      @param p_code in varchar2 code chaine du parametre 
      @return Cette fonction permet de recuperer la nature du parametre LOV ou PARAMETRE

 **/
  function get_natureparam(p_code in varchar2) return varchar2 ;

/**
ce
    
    @param p_code in varchar2
    @param p_nature in varchar2
    @return  cette fonction permet de ramener le type du parametre varchar2, date ou number

**/
  function get_typeparam(p_code in varchar2, p_nature in varchar2) return varchar2 ;


/** 
    @param p_code in varchar2  CODE DE LA LOV
    @param p_code_value in varchar2   CODE DE LA LIGNE DE LA LOV
    @return  Cette fonction permet de recuperer le libelle du code d'une lov
**/
  function get_libellelov_bycode(p_code in varchar2, p_code_value in varchar2) return varchar2;

END PARAMETRE_PKG;
/

