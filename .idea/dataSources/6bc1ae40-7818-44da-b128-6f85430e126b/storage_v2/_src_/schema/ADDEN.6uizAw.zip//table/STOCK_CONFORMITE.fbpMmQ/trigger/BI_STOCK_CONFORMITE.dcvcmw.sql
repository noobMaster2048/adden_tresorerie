create trigger BI_STOCK_CONFORMITE
    before insert
    on STOCK_CONFORMITE
    for each row
begin   
  if :NEW."ID_CONFORMITE" is null then 
    select "STOCK_CONFORMITE_SEQ".nextval into :NEW."ID_CONFORMITE" from sys.dual; 
  end if; 
end;

/

